import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/user.dart' as app_user;

class AuthService with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  app_user.User? _currentUser;
  app_user.User? get currentUser => _currentUser;

  Future<app_user.User?> _userFromFirebase(User? firebaseUser) async {
    if (firebaseUser == null) return null;

    final userDoc =
        await _firestore.collection('users').doc(firebaseUser.uid).get();

    if (!userDoc.exists) return null;

    final data = userDoc.data()!;
    return app_user.User.fromMap(data);
  }

  Stream<app_user.User?> get user {
    return _auth.authStateChanges().asyncMap(_userFromFirebase);
  }

  Future<app_user.User?> signInWithEmailAndPassword(
    String email,
    String password,
  ) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Obtener el UID del usuario autenticado
      final uid = result.user?.uid;
      if (uid == null) throw Exception('Usuario no tiene UID');

      // Obtener documento del usuario desde Firestore
      final docSnapshot =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();

      if (!docSnapshot.exists)
        throw Exception('Usuario no encontrado en Firestore');

      final userData = docSnapshot.data()!;
      final isActive = userData['isActive'] as bool? ?? false;
      final fechaFinStr = userData['fechaFin'] as String?;
      DateTime? fechaFin =
          fechaFinStr != null ? DateTime.tryParse(fechaFinStr) : null;

      // Verifica si la fecha de fin ha pasado
      if (fechaFin != null && DateTime.now().isAfter(fechaFin)) {
        // Si la fecha ya pasó, desactivar usuario
        await FirebaseFirestore.instance.collection('users').doc(uid).update({
          'isActive': false,
        });
        throw FirebaseAuthException(
          code: 'user-disabled',
          message:
              'Tu cuenta ha sido desactivada por haber superado la fecha de acceso.',
        );
      }

      // Si sigue activo, continúa el flujo
      _currentUser = await _userFromFirebase(result.user);
      notifyListeners();
      return _currentUser;
    } on FirebaseAuthException catch (e) {
      print('Error de autenticación: ${e.code} - ${e.message}');
      rethrow;
    } catch (e) {
      print('Error desconocido: $e');
      rethrow;
    }
  }

  Future<void> registerWithEmailAndPassword(
    String email,
    String password,
    String displayName,
  ) async {
    try {
      // 1. Crear usuario en Firebase Auth
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // 2. Actualizar displayName en Firebase Auth
      if (displayName.isNotEmpty) {
        await result.user?.updateDisplayName(displayName);
        await result.user?.reload(); // Recargar datos del usuario
      }

      // 3. Crear documento del usuario en Firestore
      await _firestore.collection('users').doc(result.user?.uid).set({
        'uid': result.user?.uid,
        'email': email,
        'displayName': displayName,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'role': 'user',
        'isActive': false,
        'failedAttempts': 0,
        'agencia': '',
      });
    } catch (e) {
      print('Error en registro: $e');
      rethrow;
    }
  }

  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      print('Error sending password reset email: $e');
      rethrow;
    }
  }

  Future<void> signOut() async {
    try {
      await _auth.signOut();
      _currentUser = null; // <- Limpia el usuario
      notifyListeners();
      print('Sesión cerrada exitosamente');
    } catch (e) {
      print('Error al cerrar sesión: $e');
      rethrow;
    }
  }

  // Método adicional para actualizar datos del usuario en Firestore
  Future<void> updateUserData({
    required String uid,
    required String email,
    required String role,
    required bool isActive,
    required bool isAproved,
    String? agencia,
    String? fechaInicio,
    String? fechaFin,
  }) async {
    await _firestore.collection('users').doc(uid).update({
      'email': email,
      'role': role,
      'isActive': isActive,
      'approvedByAdmin': isAproved,
      'agencia': agencia,
      'fechaInicio': fechaInicio,
      'fechaFin': fechaFin,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}
