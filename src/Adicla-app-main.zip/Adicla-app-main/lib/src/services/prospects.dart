import 'package:adicla/src/provider/auth_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DatabaseMethods {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Lista quemada de departamentos y municipios
  final List<Map<String, dynamic>> _departamentos = [
    {
      "title": "Escuintla",
      "mun": [
        "Santa Lucia Cotzumalguapa",
        "Siquinalá",
        "Sipacate",
        "La Gomera",
        "La Democracia",
        "La Nueva Concepción",
      ],
    },
    {
      "title": "Santa Cruz del Quiché",
      "mun": ["Chichicastenango"],
    },
    {
      "title": "Suchitepéquez",
      "mun": [
        "Santo Tomas La Unión",
        "Samayac",
        "San Antonio",
        "Chicacao",
        "Rio Bravo",
        "Santa Barbara",
        "Patulul",
        "Mazatenango",
        "Santo Domingo",
        "Cuyotenango",
      ],
    },
    {
      "title": "Retalhuleu",
      "mun": [
        "San Andrés Villa Seca",
        "San Francisco Zapotitlán",
        "Retalhuleu",
      ],
    },
    {
      "title": "Chimaltenango",
      "mun": [
        "Acatenango",
        "Chimaltenango",
        "El Tejar",
        "Patzicía",
        "Patzún",
        "San Andrés Itzapa",
        "San José Poaquil",
        "San Juan Comalapa",
        "San Martín Jilotepeque",
        "Santa Apolonia",
        "Santa Cruz Balanyá",
        "Tecpán",
        "Yepocapa",
        "Zaragoza",
        "San Miguel Pochuta",
        "Parramos",
      ],
    },
    {
      "title": "Sololá",
      "mun": [
        "Concepción",
        "Nahualá",
        "Panajachel",
        "San José Chacayá",
        "San Juan la Laguna",
        "San Marcos la Laguna",
        "San Pablo la Laguna",
        "Santa Catarina Ixtahuacán",
        "Santa Clara la Laguna",
        "Sololá",
        "San Andrés Semetabaj",
        "San Lucas Tolimán",
        "Santa Catarina Palopó",
        "San Antonio Palopó",
      ],
    },
    {
      "title": "Totonicapán",
      "mun": ["Totonicapán"],
    },
  ];

  // Método para obtener la lista de departamentos
  Future<List<String>> getDepartamentos() async {
    return _departamentos.map((depto) => depto['title'] as String).toList();
  }

  // Método para obtener la lista de municipios con su departamento
  Future<List<Map<String, dynamic>>> getMunicipios() async {
    List<Map<String, dynamic>> municipios = [];

    for (var depto in _departamentos) {
      final departamento = depto['title'] as String;
      final munList = depto['mun'] as List<String>;

      for (var municipio in munList) {
        municipios.add({'departamento': departamento, 'nombre': municipio});
      }
    }

    return municipios;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> getProspectsStream({
    required String currentUserId,
  }) async* {
    final userDoc =
        await _firestore.collection('Users').doc(currentUserId).get();
    final isAdmin = userDoc.data()?['role'] == 'admin';

    Query<Map<String, dynamic>> query = _firestore.collection("Prospect");

    if (!isAdmin) {
      query = query.where('creadoPorId', isEqualTo: currentUserId);
    }

    yield* query.orderBy('fechaRegistro', descending: true).snapshots();
  }

  // Obtener lista de asesores
  Future<List<QueryDocumentSnapshot>> getAsesores() async {
    final snapshot =
        await _firestore
            .collection('Users')
            .where('role', isEqualTo: 'asesor')
            .get();
    return snapshot.docs;
  }

  Stream<QuerySnapshot> searchProspectsStream({
    required BuildContext context,
    String query = '',
    String? departamento,
    String? municipio,
    String? direccion,
  }) {
    // Obtén el AuthService y el UID del usuario actual
    final authService = Provider.of<AuthService>(context, listen: false);
    final currentUserId = authService.currentUser?.uid;

    print('Aplicando filtros de búsqueda:');
    print(' - Usuario: $currentUserId');
    print(' - Query: $query');
    print(' - Departamento: $departamento');
    print(' - Municipio: $municipio');
    print(' - Dirección: $direccion');

    // Si no hay usuario, retorna un stream vacío
    if (currentUserId == null) {
      return const Stream.empty();
    }

    // Comenzamos con la colección y el filtro obligatorio de userId
    Query collection = _firestore
        .collection('Prospect')
        .where('creadoPorId', isEqualTo: currentUserId);

    // Aplicamos filtros adicionales
    if (departamento != null && departamento.isNotEmpty) {
      print('Aplicando filtro de departamento: $departamento');
      collection = collection.where('departamento', isEqualTo: departamento);
    }

    if (municipio != null && municipio.isNotEmpty) {
      print('Aplicando filtro de municipio: $municipio');
      collection = collection.where('municipio', isEqualTo: municipio);
    }

    if (query.isNotEmpty) {
      print('Aplicando filtro de texto (nombre): $query');
      collection = collection
          .where('nombre', isGreaterThanOrEqualTo: query)
          .where('nombre', isLessThan: query + 'z');
    }

    if (direccion != null && direccion.isNotEmpty) {
      print('Aplicando filtro de dirección: $direccion');
      collection = collection
          .where('direccion', isGreaterThanOrEqualTo: direccion)
          .where('direccion', isLessThan: direccion + 'z');
    }

    return collection.snapshots();
  }

  // 2. Actualizar prospecto
  Future<void> updateProspect(
    String id,
    Map<String, dynamic> updateInfo,
  ) async {
    try {
      await _firestore.collection("Prospect").doc(id).update(updateInfo);
    } catch (e) {
      throw "Error al actualizar prospecto: $e";
    }
  }

  // 3. Eliminar prospecto
  Future<void> deleteProspect(String id) async {
    try {
      await _firestore.collection("Prospect").doc(id).delete();
    } catch (e) {
      throw "Error al eliminar prospecto: $e";
    }
  }

  // 4. Crear nuevo prospecto (opcional, si lo necesitas)
  Future<void> addProspect(
    Map<String, dynamic> prospectInfoMap,
    String id,
  ) async {
    try {
      await _firestore.collection("Prospect").doc(id).set(prospectInfoMap);
    } catch (e) {
      throw "Error al crear prospecto: $e";
    }
  }
}
