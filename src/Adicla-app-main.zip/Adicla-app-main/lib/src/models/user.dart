import 'package:cloud_firestore/cloud_firestore.dart';

class User {
  final String uid;
  final String email;
  final String? displayName;
  final String? photoUrl;
  final String role;
  final bool isActive;
  final DateTime? lastActive;
  final List<String> unlockedBadges;
  final Map<String, dynamic>? preferences;

  User({
    required this.uid,
    required this.email,
    this.displayName,
    this.photoUrl,
    this.role = 'user',
    this.isActive = false,
    this.lastActive,
    this.unlockedBadges = const [],
    this.preferences,
  });

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      uid: map['uid'],
      email: map['email'],
      displayName: map['displayName'],
      photoUrl: map['photoUrl'],
      role: map['role'] ?? 'user',
      isActive: map['isActive'] ?? false,
      lastActive:
          map['lastActive'] != null
              ? (map['lastActive'] is Timestamp
                  ? (map['lastActive'] as Timestamp).toDate()
                  : DateTime.parse(map['lastActive']))
              : null,
      unlockedBadges: List<String>.from(map['unlockedBadges'] ?? []),
      preferences: map['preferences'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'role': role,
      'isActive': isActive,
      'lastActive': lastActive?.toIso8601String(),
      'unlockedBadges': unlockedBadges,
      'preferences': preferences,
    };
  }
}
