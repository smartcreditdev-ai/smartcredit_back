class ImageConstant {
  static String imgGroup17 = 'assets/images/img_group_17.svg';

  static String imgArrowrightYellow900 =
      'assets/images/img_arrowright_yellow_900.svg';

  static String imgCheckmarkBlack900 =
      'assets/images/img_checkmark_black_900.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowleftGray90001 =
      'assets/images/img_arrowleft_gray_900_01.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgGroup9 = 'assets/images/img_group9.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgMenuGray500 = 'assets/images/img_menu_gray_500.svg';

  static String imgArrowleftBlack900 =
      'assets/images/img_arrowleft_black_900.svg';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgImage1 = 'assets/images/img_image1.png';

  static String imgIconlyBoldBag = 'assets/images/img_iconly_bold_bag.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgIconlyboldedit = 'assets/images/img_iconlyboldedit.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';

  static String imgGrid = 'assets/images/img_grid.svg';

  static String imgMethodPayment = "assets/VECTOR_RENDEM.svg";

  static String imgSearchYellow900 = 'assets/images/img_search_yellow_900.svg';

  static String imgApproval11 = 'assets/images/img_approval11.svg';

  static String imgImage5 = 'assets/images/img_image5.png';

  static String imgDownload = 'assets/images/img_download.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgCheckmarkGreen700 =
      'assets/images/img_checkmark_green_700.svg';

  static String imgAirplane = 'assets/images/img_airplane.svg';

  static String imgVector1 = 'assets/images/img_vector1.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgVector1Yellow900 =
      'assets/images/img_vector1_yellow_900.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgCheckmarkYellow900 =
      'assets/images/img_checkmark_yellow_900.svg';

  static String imgHomeWhiteA700 = 'assets/images/img_home_white_a700.svg';

  static String imgUnnamed1 = 'assets/images/img_unnamed1.png';

  static String imgMobile = 'assets/images/img_mobile.svg';

  static String imgPolygon1 = 'assets/images/img_polygon1.svg';

  static String imgAirplaneYellow900 =
      'assets/images/img_airplane_yellow_900.svg';

  static String imgHeader = 'assets/images/img_header.svg';

  static String imgArrowrightYellow90010x6 =
      'assets/images/img_arrowright_yellow_900_10x6.svg';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgCalendar = 'assets/images/img_calendar.svg';
}
