import 'package:adicla/src/provider/auth_service.dart';
import 'package:adicla/src/view/auth/login_view.dart';
import 'package:adicla/src/view/pages/Home_pages.dart';
import 'package:adicla/src/view/pages/Multi_step_form.dart';
import 'package:adicla/src/view/pages/Seguimientos_screen.dart';
import 'package:adicla/src/view/pages/prospects_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:adicla/src/view/pages/Seguimiento_form.dart';

Widget buildDrawer(BuildContext context) {
  return Drawer(
    child: ListView(
      padding: EdgeInsets.zero,
      children: [
        const DrawerHeader(
          decoration: BoxDecoration(color: Color.fromRGBO(51, 67, 139, 1)),
          child: Text(
            'Menú Principal',
            style: TextStyle(color: Colors.white, fontSize: 24),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.home),
          title: const Text('Inicio'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const HomePages()),
            );
          },
        ),
        ListTile(
          leading: const Icon(Icons.analytics),
          title: const Text('Ver Prospectos'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const ProspectsView()),
            );
          },
        ),
        ListTile(
          leading: const Icon(Icons.add_circle_outline),
          title: const Text('Nuevo Prospecto'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const MultiStepForm()),
            );
          },
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.schedule_outlined),
          title: const Text('Seguimiento'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SeguimientoForm()),
            );
          },
        ),
        ListTile(
          leading: const Icon(Icons.search), // Changed to magnifying glass icon
          title: const Text('Ver Seguimientos'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SeguimientosScreen()),
            );
          },
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.exit_to_app),
          title: const Text('Cerrar Sesión'),
          onTap: () {
            Navigator.pop(context);
            final authService = Provider.of<AuthService>(
              context,
              listen: false,
            );
            authService
                .signOut()
                .then((_) {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LoginScreen(),
                    ),
                    (Route<dynamic> route) => false,
                  );
                })
                .catchError((error) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error al cerrar sesión: $error')),
                  );
                });
          },
        ),
      ],
    ),
  );
}