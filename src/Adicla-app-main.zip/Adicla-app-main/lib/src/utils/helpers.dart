import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

// Muestra un SnackBar con estilo consistente
void showSnackBar(
  BuildContext context,
  String message, {
  bool isError = false,
  Duration duration = const Duration(seconds: 3),
  String? actionLabel,
  VoidCallback? onAction,
  double elevation = 6.0,
  EdgeInsetsGeometry? margin,
}) {
  // Verificar si el contexto está montado
  if (!context.mounted) return;

  // Margen predeterminado que evita interferencias con otros elementos
  final defaultMargin = EdgeInsets.only(
    bottom: MediaQuery.of(context).size.height * 0.1,
    left: 10,
    right: 10,
  );

  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        message,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
      backgroundColor: isError ? Colors.red[700] : Colors.green[700],
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: margin ?? defaultMargin,
      duration: duration,
      elevation: elevation,
      action:
          actionLabel != null
              ? SnackBarAction(
                label: actionLabel,
                textColor: Colors.white,
                onPressed: onAction ?? () {},
              )
              : null,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
  );
}

// Formatea fechas de manera amigable
String formatDate(DateTime date, {bool withTime = false}) {
  if (withTime) {
    return DateFormat('MMM dd, yyyy - hh:mm a').format(date);
  }
  return DateFormat('MMM dd, yyyy').format(date);
}

// Calcula el tiempo restante para una tarea
String timeRemaining(DateTime dueDate) {
  final now = DateTime.now();
  final difference = dueDate.difference(now);

  if (difference.inDays > 0) {
    return '${difference.inDays}d restante${difference.inDays > 1 ? 's' : ''}';
  } else if (difference.inHours > 0) {
    return '${difference.inHours}h restante${difference.inHours > 1 ? 's' : ''}';
  } else if (difference.inMinutes > 0) {
    return '${difference.inMinutes}m restante${difference.inMinutes > 1 ? 's' : ''}';
  } else if (difference.inSeconds > 0) {
    return '${difference.inSeconds}s restante${difference.inSeconds > 1 ? 's' : ''}';
  }
  return 'Vencido';
}

// Valida un correo electrónico
bool isValidEmail(String email) {
  return RegExp(
    r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$',
  ).hasMatch(email);
}

// Calcula el nivel basado en XP
int calculateLevel(int xp) {
  return (xp / 1000).floor() + 1;
}

// Calcula el progreso hacia el siguiente nivel
double calculateLevelProgress(int xp) {
  final levelXp = xp % 1000;
  return levelXp / 1000;
}

// Muestra un diálogo de confirmación
Future<bool> showConfirmationDialog(
  BuildContext context, {
  required String title,
  required String content,
  String confirmText = 'Confirmar',
  String cancelText = 'Cancelar',
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder:
        (context) => AlertDialog(
          title: Text(title),
          content: Text(content),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(cancelText),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(confirmText),
            ),
          ],
        ),
  );
  return result ?? false;
}

// Función para capitalizar la primera letra
String capitalize(String text) {
  if (text.isEmpty) return text;
  return text[0].toUpperCase() + text.substring(1);
}

// Obtiene el color según la prioridad de la tarea
Color getPriorityColor(TaskPriority priority) {
  switch (priority) {
    case TaskPriority.high:
      return Colors.red[400]!;
    case TaskPriority.medium:
      return Colors.orange[400]!;
    case TaskPriority.low:
      return Colors.green[400]!;
  }
}

// Enum para prioridad de tareas (deberías tenerlo en tu models/task.dart)
enum TaskPriority { low, medium, high }
