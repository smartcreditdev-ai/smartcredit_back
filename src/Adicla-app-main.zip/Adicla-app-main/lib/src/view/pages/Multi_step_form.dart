import 'package:adicla/src/provider/auth_service.dart';
import 'package:adicla/src/services/prospects.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';

class MultiStepForm extends StatefulWidget {
  const MultiStepForm({super.key});

  @override
  State<MultiStepForm> createState() => _MultiStepFormState();
}

class _MultiStepFormState extends State<MultiStepForm> {
  int _currentStep = 0;
  final PageController _pageController = PageController();

  // Controladores para los campos del formulario
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _apellidoController = TextEditingController();
  final TextEditingController _telefonoController = TextEditingController();
  final TextEditingController _direccionController = TextEditingController();
  final TextEditingController _departamentoController = TextEditingController();
  final TextEditingController _municipioController = TextEditingController();
  final TextEditingController _referidoPorController = TextEditingController();

  // Controladores para campos de promoción
  final TextEditingController _tipoPromocionController =
      TextEditingController();
  final TextEditingController _sabiaAdiclaController = TextEditingController();
  final TextEditingController _comoEnteroController = TextEditingController();
  final TextEditingController _etapaController = TextEditingController();

  // Focus nodes para manejar el teclado
  final FocusNode _nombreFocus = FocusNode();
  final FocusNode _apellidoFocus = FocusNode();
  final FocusNode _telefonoFocus = FocusNode();
  final FocusNode _direccionFocus = FocusNode();
  final FocusNode _departamentoFocus = FocusNode();
  final FocusNode _municipioFocus = FocusNode();
  final FocusNode _referidoPorFocus = FocusNode();

  final List<Map<String, dynamic>> _departamentos = [
    {
      "title": "Escuintla",
      "mun": [
        "Santa Lucia Cotzumalguapa",
        "Siquinalá",
        "Sipacate",
        "La Gomera",
        "La Democracia",
        "La Nueva Concepción",
      ],
    },
    {
      "title": "Santa Cruz del Quiché",
      "mun": ["Chichicastenango"],
    },
    {
      "title": "Suchitepéquez",
      "mun": [
        "Santo Tomas La Unión",
        "Samayac",
        "San Antonio",
        "Chicacao",
        "Rio Bravo",
        "Santa Barbara",
        "Patulul",
        "Mazatenango",
        "Santo Domingo",
        "Cuyotenango",
      ],
    },
    {
      "title": "Retalhuleu",
      "mun": [
        "San Andrés Villa Seca",
        "San Francisco Zapotitlán",
        "Retalhuleu",
      ],
    },
    {
      "title": "Chimaltenango",
      "mun": [
        "Acatenango",
        "Chimaltenango",
        "El Tejar",
        "Patzicía",
        "Patzún",
        "San Andrés Itzapa",
        "San José Poaquil",
        "San Juan Comalapa",
        "San Martín Jilotepeque",
        "Santa Apolonia",
        "Santa Cruz Balanyá",
        "Tecpán",
        "Yepocapa",
        "Zaragoza",
        "San Miguel Pochuta",
        "Parramos",
      ],
    },
    {
      "title": "Sololá",
      "mun": [
        "Concepción",
        "Nahualá",
        "Panajachel",
        "San José Chacayá",
        "San Juan la Laguna",
        "San Marcos la Laguna",
        "San Pablo la Laguna",
        "Santa Catarina Ixtahuacán",
        "Santa Clara la Laguna",
        "Sololá",
        "San Andrés Semetabaj",
        "San Lucas Tolimán",
        "Santa Catarina Palopó",
        "San Antonio Palopó",
      ],
    },
    {
      "title": "Totonicapán",
      "mun": ["Totonicapán"],
    },
  ];

  List<String> _municipios = [];
  String? _selectedDepartamento;
  String? _selectedMunicipio;

  // Variables para selecciones
  String? _selectedTipoPromocion;
  String? _selectedSabiaAdicla;
  String? _selectedComoEntero;
  String? _selectedEtapa;

  // Opciones para los dropdowns
  final List<String> _tipoPromocionOptions = [
    'Nuevo',
    'Referido',
    'Recurrente',
    'Desertado',
  ];
  final List<String> _sabiaAdiclaOptions = ['Sí', 'No'];
  final List<String> _comoEnteroOptions = [
    'Facebook',
    'Instagram',
    'WhatsApp',
    'TikTok',
    'Página web',
    'Volante',
    'Radio',
    'Por un amigo',
    'Por un familiar',
    'Visita de asesor',
    'Rótulo',
    'Unidad móvil',
  ];
  final List<String> _etapaOptions = [
    'No interesado',
    'No cumple con los requisitos',
    'Seguimiento',
    'Solicitud generada',
    'Rechazado',
    'Aprobado',
  ];

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _nombreController.dispose();
    _apellidoController.dispose();
    _telefonoController.dispose();
    _direccionController.dispose();
    _departamentoController.dispose();
    _municipioController.dispose();
    _tipoPromocionController.dispose();
    _sabiaAdiclaController.dispose();
    _comoEnteroController.dispose();
    _etapaController.dispose();
    _referidoPorController.dispose();
    _pageController.dispose();

    _nombreFocus.dispose();
    _apellidoFocus.dispose();
    _telefonoFocus.dispose();
    _direccionFocus.dispose();
    _departamentoFocus.dispose();
    _municipioFocus.dispose();
    _referidoPorFocus.dispose();

    super.dispose();
  }

  void _updateMunicipios(String? departamento) {
    if (departamento == null) {
      setState(() {
        _municipios = [];
        _selectedMunicipio = null;
        _municipioController.clear();
      });
      return;
    }

    final depto = _departamentos.firstWhere(
      (d) => d['title'] == departamento,
      orElse: () => {'mun': []},
    );

    setState(() {
      _municipios = List<String>.from(depto['mun'] ?? []);
      _selectedMunicipio = null;
      _municipioController.clear();
    });
  }

  void _nextStep() {
    FocusManager.instance.primaryFocus?.unfocus();

    // Validar el paso actual antes de avanzar
    bool isValid = true;
    switch (_currentStep) {
      case 0: // Nombre y apellido
        if (_nombreController.text.isEmpty ||
            _apellidoController.text.isEmpty) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor completa todos los campos requeridos'),
            ),
          );
        }
        break;
      case 1: // Departamento y municipio
        if (_selectedDepartamento == null || _selectedMunicipio == null) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor selecciona departamento y municipio'),
            ),
          );
        }
        break;
      case 2: // Dirección
        if (_direccionController.text.isEmpty) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Por favor ingresa una dirección')),
          );
        }
        break;
      case 3: // Teléfono
        if (_telefonoController.text.isEmpty) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor ingresa un número de teléfono'),
            ),
          );
        }
        break;
      case 4: // Tipo de promoción
        if (_selectedTipoPromocion == null) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor selecciona un tipo de promoción'),
            ),
          );
        }
        break;
      case 5: // Campos condicionales según tipo de promoción
        if (_selectedTipoPromocion == 'Nuevo' && _selectedSabiaAdicla == null) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor indica si sabía de Adicla'),
            ),
          );
        } else if (_selectedTipoPromocion == 'Referido' &&
            _referidoPorController.text.isEmpty) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor ingresa el nombre de quien te refirió'),
            ),
          );
        }
        break;
      case 6: // Solo para tipo "Nuevo" - ¿Cómo se enteró?
        if (_selectedTipoPromocion == 'Nuevo' && _selectedComoEntero == null) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor indica cómo se enteró de Adicla'),
            ),
          );
        }
        break;
      case 7: // Solo para tipo "Nuevo" - Etapa
        if (_selectedTipoPromocion == 'Nuevo' && _selectedEtapa == null) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Por favor selecciona una etapa')),
          );
        }
        break;
    }

    if (!isValid) return;

    // Calcular el número máximo de pasos según el tipo de promoción
    final maxSteps = _getMaxSteps();

    if (_currentStep < maxSteps - 1) {
      setState(() {
        _currentStep++;
        _pageController.nextPage(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      });
    } else {
      _submitForm();
    }
  }

  int _getMaxSteps() {
    if (_selectedTipoPromocion == 'Nuevo') {
      return 8; // Todos los pasos incluyendo los específicos para "Nuevo"
    } else if (_selectedTipoPromocion == 'Referido') {
      return 6; // Pasos básicos + referido por
    } else {
      return 5; // Solo pasos básicos
    }
  }

  void _previousStep() {
    FocusManager.instance.primaryFocus?.unfocus();

    if (_currentStep > 0) {
      setState(() {
        _currentStep--;
        _pageController.previousPage(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      });
    }
  }

  Future<void> _submitForm() async {
    // Validar campos requeridos
    if (_nombreController.text.isEmpty || _apellidoController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nombre y apellido son requeridos')),
      );
      return;
    }

    try {
      // Obtener el servicio de autenticación sin escuchar cambios
      final authService = Provider.of<AuthService>(context, listen: false);
      final user = authService.currentUser;

      // Crear mapa de datos
      final prospectData = {
        'nombre': _nombreController.text,
        'apellido': _apellidoController.text,
        'telefono':
            _telefonoController.text.isNotEmpty
                ? _telefonoController.text
                : null,
        'direccion':
            _direccionController.text.isNotEmpty
                ? _direccionController.text
                : null,
        'departamento': _selectedDepartamento,
        'municipio': _selectedMunicipio,
        'tipoPromocion': _selectedTipoPromocion,
        'fechaRegistro': FieldValue.serverTimestamp(),
        'asesor': user?.displayName,
        'creadoPorId':
            user?.uid, // <-- Aquí agregamos el UID del usuario que crea el prospecto
        // Campos condicionales
        if (_selectedTipoPromocion == 'Nuevo') ...{
          'sabiaAdicla': _selectedSabiaAdicla,
          'comoSeEntero': _selectedComoEntero,
          'etapa': _selectedEtapa,
        },

        if (_selectedTipoPromocion == 'Referido') ...{
          'referidoPor': _referidoPorController.text,
        },
      };

      debugPrint('Submitting prospect data: $prospectData');

      // Mostrar indicador de carga
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(child: CircularProgressIndicator()),
      );

      // Guardar en Firebase
      final db = DatabaseMethods();
      final id = DateTime.now().millisecondsSinceEpoch.toString();
      await db.addProspect(prospectData, id);

      debugPrint('Prospect saved successfully');

      // Cerrar dialogo y volver solo si el widget está montado
      if (mounted) {
        Navigator.pop(context); // Cierra el loading
        Navigator.pop(context); // Cierra el formulario

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Prospecto guardado exitosamente')),
        );
      }
    } catch (e) {
      debugPrint('Error saving prospect: $e');
      if (mounted) {
        Navigator.pop(context); // Cierra el loading si hay error
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al guardar: ${e.toString()}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Formulario'), centerTitle: true),
      body: GestureDetector(
        onTap: () {
          FocusManager.instance.primaryFocus?.unfocus();
        },
        child: Column(
          children: [
            LinearProgressIndicator(
              value: (_currentStep + 1) / _getMaxSteps(),
              backgroundColor: Colors.grey[200],
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color.fromRGBO(51, 67, 139, 1),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Paso ${_currentStep + 1} de ${_getMaxSteps()}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _buildStep1(), // Nombre y apellido
                  _buildStep2(), // Departamento y municipio
                  _buildStep3(), // Dirección
                  _buildStep4(), // Teléfono
                  _buildStep5(), // Tipo de promoción
                  _buildStep6(), // Campos condicionales según tipo de promoción
                  if (_selectedTipoPromocion == 'Nuevo')
                    _buildStep7(), // ¿Cómo se enteró?
                  if (_selectedTipoPromocion == 'Nuevo') _buildStep8(), // Etapa
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (_currentStep > 0)
                    ElevatedButton(
                      onPressed: _previousStep,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 12,
                        ),
                      ),
                      child: const Text(
                        'Atrás',
                        style: TextStyle(color: Colors.white),
                      ),
                    )
                  else
                    const SizedBox(width: 100),
                  ElevatedButton(
                    onPressed: _nextStep,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromRGBO(51, 67, 139, 1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                    ),
                    child: Text(
                      _currentStep == _getMaxSteps() - 1
                          ? 'Enviar'
                          : 'Siguiente',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStep1() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Información Personal',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          TextFormField(
            controller: _nombreController,
            focusNode: _nombreFocus,
            decoration: const InputDecoration(
              labelText: 'Nombre',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor ingresa tu nombre';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _apellidoController,
            focusNode: _apellidoFocus,
            decoration: const InputDecoration(
              labelText: 'Apellido',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person_outline),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor ingresa tu apellido';
              }
              return null;
            },
          ),
          SizedBox(
            height: MediaQuery.of(context).viewInsets.bottom > 0 ? 200 : 0,
          ),
        ],
      ),
    );
  }

  Widget _buildStep2() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Ubicación',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _selectedDepartamento,
            decoration: const InputDecoration(
              labelText: 'Departamento',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.location_city),
            ),
            items:
                _departamentos.map((depto) {
                  return DropdownMenuItem<String>(
                    value: depto['title'],
                    child: Text(depto['title']),
                  );
                }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _selectedDepartamento = newValue;
                _departamentoController.text = newValue ?? '';
                _updateMunicipios(newValue);
              });
            },
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _selectedMunicipio,
            decoration: InputDecoration(
              labelText: 'Municipio',
              border: const OutlineInputBorder(),
              prefixIcon: const Icon(Icons.public),
              enabled: _selectedDepartamento != null,
              hintText:
                  _selectedDepartamento == null
                      ? 'Selecciona un departamento primero'
                      : null,
            ),
            items:
                _municipios.map((mun) {
                  return DropdownMenuItem<String>(value: mun, child: Text(mun));
                }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _selectedMunicipio = newValue;
                _municipioController.text = newValue ?? '';
              });
            },
          ),
          SizedBox(
            height: MediaQuery.of(context).viewInsets.bottom > 0 ? 200 : 0,
          ),
        ],
      ),
    );
  }

  Widget _buildStep3() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Dirección',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          TextFormField(
            controller: _direccionController,
            focusNode: _direccionFocus,
            decoration: const InputDecoration(
              labelText: 'Dirección completa',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.home),
            ),
          ),
          SizedBox(
            height: MediaQuery.of(context).viewInsets.bottom > 0 ? 200 : 0,
          ),
        ],
      ),
    );
  }

  Widget _buildStep4() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Contacto',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          TextFormField(
            controller: _telefonoController,
            focusNode: _telefonoFocus,
            decoration: const InputDecoration(
              labelText: 'Teléfono',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.phone),
            ),
            keyboardType: TextInputType.phone,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          ),
          SizedBox(
            height: MediaQuery.of(context).viewInsets.bottom > 0 ? 200 : 0,
          ),
        ],
      ),
    );
  }

  Widget _buildStep5() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Tipo de Promoción',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _selectedTipoPromocion,
            decoration: const InputDecoration(
              labelText: 'Tipo de promoción',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.local_offer),
            ),
            items:
                _tipoPromocionOptions.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _selectedTipoPromocion = newValue;
                _tipoPromocionController.text = newValue ?? '';
              });
            },
          ),
          SizedBox(
            height: MediaQuery.of(context).viewInsets.bottom > 0 ? 200 : 0,
          ),
        ],
      ),
    );
  }

  Widget _buildStep6() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Información Adicional',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          if (_selectedTipoPromocion == 'Nuevo') ...[
            DropdownButtonFormField<String>(
              value: _selectedSabiaAdicla,
              decoration: const InputDecoration(
                labelText: '¿Sabía de Adicla?',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.help_outline),
              ),
              items:
                  _sabiaAdiclaOptions.map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  _selectedSabiaAdicla = newValue;
                  _sabiaAdiclaController.text = newValue ?? '';
                });
              },
            ),
          ],
          if (_selectedTipoPromocion == 'Referido') ...[
            const SizedBox(height: 16),
            TextFormField(
              controller: _referidoPorController,
              focusNode: _referidoPorFocus,
              decoration: const InputDecoration(
                labelText: 'Nombre completo de quien lo refirió',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person_add),
              ),
            ),
          ],
          SizedBox(
            height: MediaQuery.of(context).viewInsets.bottom > 0 ? 200 : 0,
          ),
        ],
      ),
    );
  }

  Widget _buildStep7() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '¿Cómo se enteró de Adicla?',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _selectedComoEntero,
            decoration: const InputDecoration(
              labelText: 'Medio por el que se enteró',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.info_outline),
            ),
            items:
                _comoEnteroOptions.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _selectedComoEntero = newValue;
                _comoEnteroController.text = newValue ?? '';
              });
            },
          ),
          SizedBox(
            height: MediaQuery.of(context).viewInsets.bottom > 0 ? 200 : 0,
          ),
        ],
      ),
    );
  }

  Widget _buildStep8() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Etapa del Proceso',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _selectedEtapa,
            decoration: const InputDecoration(
              labelText: 'Etapa actual',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.timeline),
            ),
            items:
                _etapaOptions.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _selectedEtapa = newValue;
                _etapaController.text = newValue ?? '';
              });
            },
          ),
          SizedBox(
            height: MediaQuery.of(context).viewInsets.bottom > 0 ? 200 : 0,
          ),
        ],
      ),
    );
  }
}
