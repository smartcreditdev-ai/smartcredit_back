import 'package:adicla/src/utils/drawer.dart';
import 'package:flutter/material.dart';

class FollowUpPages extends StatefulWidget {
  const FollowUpPages({super.key});

  @override
  State<FollowUpPages> createState() => _FollowUpPagesState();
}

class _FollowUpPagesState extends State<FollowUpPages> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Colors.black),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: Text('Seguimiento'),
      ),
      drawer: buildDrawer(context),
      body: Center(
        child: Container(
          child: Text(
            'Estamos trabajando en esto...',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
