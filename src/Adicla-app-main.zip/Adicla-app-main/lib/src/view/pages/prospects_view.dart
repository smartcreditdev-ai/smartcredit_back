import 'package:adicla/src/provider/auth_service.dart';
import 'package:adicla/src/services/prospects.dart';
import 'package:adicla/src/utils/drawer.dart';
import 'package:adicla/src/view/pages/multi_step_form.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class ProspectsView extends StatefulWidget {
  const ProspectsView({super.key});

  @override
  State<ProspectsView> createState() => _ProspectsViewState();
}

class _ProspectsViewState extends State<ProspectsView> {
  final DatabaseMethods _databaseMethods = DatabaseMethods();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context, listen: false);
    final currentUserId = authService.currentUser?.uid ?? '';

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Colors.black),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: const Text('Gestión de Prospectos'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_alt),
            onPressed: () {
              showSearch(
                context: context,
                delegate: ProspectSearchDelegate(_databaseMethods, currentUserId),
              );
            },
          ),
        ],
      ),
      drawer: buildDrawer(context),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const MultiStepForm()),
          );
        },
        backgroundColor: const Color.fromRGBO(51, 67, 139, 1),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _databaseMethods.getProspectsStream(currentUserId: currentUserId),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No hay prospectos registrados'));
          }

          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              final doc = snapshot.data!.docs[index];
              final prospect = doc.data() as Map<String, dynamic>;
              final fechaRegistro = (prospect['fechaRegistro'] as Timestamp?)?.toDate();

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: ListTile(
                  title: Text(
                    '${prospect['nombre']} ${prospect['apellido']}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Tel: ${prospect['telefono'] ?? 'No especificado'}'),
                      if (fechaRegistro != null)
                        Text(
                          'Registrado: ${DateFormat('dd/MM/yyyy').format(fechaRegistro)}',
                          style: const TextStyle(fontSize: 12),
                        ),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _showEditDialog(doc.id, prospect),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _confirmDelete(doc.id),
                      ),
                    ],
                  ),
                  onTap: () => _showDetailsDialog(prospect),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _showDetailsDialog(Map<String, dynamic> prospect) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('${prospect['nombre']} ${prospect['apellido']}'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildDetailItem('Teléfono', prospect['telefono']),
                _buildDetailItem('Dirección', prospect['direccion']),
                _buildDetailItem('Departamento', prospect['departamento']),
                _buildDetailItem('Municipio', prospect['municipio']),
                _buildDetailItem('Tipo de promoción', prospect['tipoPromocion']),
                if (prospect['tipoPromocion'] == 'Nuevo') ...[
                  _buildDetailItem('Sabía de ADICLA', prospect['sabiaAdicla']),
                  _buildDetailItem('Cómo se enteró', prospect['comoSeEntero']),
                  _buildDetailItem('Etapa', prospect['etapa']),
                ],
                if (prospect['tipoPromocion'] == 'Referido')
                  _buildDetailItem('Referido por', prospect['referidoPor']),
              ],
            ),
          ),
          actions: [
            TextButton(
              child: const Text('Cerrar'),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDetailItem(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: RichText(
        text: TextSpan(
          style: DefaultTextStyle.of(context).style,
          children: [
            TextSpan(
              text: '$label: ',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: value ?? 'No especificado'),
          ],
        ),
      ),
    );
  }

  void _showEditDialog(String id, Map<String, dynamic> prospect) {
    final formKey = GlobalKey<FormState>();
    final nombreController = TextEditingController(text: prospect['nombre']);
    final apellidoController = TextEditingController(text: prospect['apellido']);
    final telefonoController = TextEditingController(text: prospect['telefono']);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Editar Prospecto'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nombreController,
                    decoration: const InputDecoration(labelText: 'Nombre'),
                    validator: (value) => value!.isEmpty ? 'Ingrese el nombre' : null,
                  ),
                  TextFormField(
                    controller: apellidoController,
                    decoration: const InputDecoration(labelText: 'Apellido'),
                    validator: (value) => value!.isEmpty ? 'Ingrese el apellido' : null,
                  ),
                  TextFormField(
                    controller: telefonoController,
                    decoration: const InputDecoration(labelText: 'Teléfono'),
                    keyboardType: TextInputType.phone,
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.pop(context),
            ),
            ElevatedButton(
              child: const Text('Guardar'),
              onPressed: () async {
                if (formKey.currentState!.validate()) {
                  try {
                    await _databaseMethods.updateProspect(id, {
                      'nombre': nombreController.text,
                      'apellido': apellidoController.text,
                      'telefono': telefonoController.text,
                      'fechaActualizacion': FieldValue.serverTimestamp(),
                    });
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Prospecto actualizado')),
                      );
                      Navigator.pop(context);
                    }
                  } catch (e) {
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Error: ${e.toString()}')),
                      );
                    }
                  }
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _confirmDelete(String id) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Confirmar eliminación'),
          content: const Text('¿Estás seguro de eliminar este prospecto?'),
          actions: [
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.pop(context),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Eliminar'),
              onPressed: () async {
                try {
                  await _databaseMethods.deleteProspect(id);
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Prospecto eliminado')),
                    );
                    Navigator.pop(context);
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Error: ${e.toString()}')),
                    );
                  }
                }
              },
            ),
          ],
        );
      },
    );
  }
}

class ProspectSearchDelegate extends SearchDelegate {
  final DatabaseMethods _databaseMethods;
  final String currentUserId;
  String? _selectedDepartamento;
  String? _selectedMunicipio;
  String? _selectedDireccion;

  ProspectSearchDelegate(this._databaseMethods, this.currentUserId);

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      if (query.isNotEmpty)
        IconButton(
          icon: const Icon(Icons.clear),
          onPressed: () {
            query = '';
            showSuggestions(context);
          },
        ),
      IconButton(
        icon: const Icon(Icons.filter_alt),
        onPressed: () async {
          final filters = await _showAdvancedFilters(context);
          if (filters != null) {
            _selectedDepartamento = filters['departamento'];
            _selectedMunicipio = filters['municipio'];
            _selectedDireccion = filters['direccion'];
            showResults(context);
          }
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return _buildSearchResults(context);
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    if (query.isEmpty &&
        _selectedDepartamento == null &&
        _selectedMunicipio == null &&
        _selectedDireccion == null) {
      return const Center(
        child: Text('Use los filtros para buscar prospectos'),
      );
    }
    return _buildSearchResults(context);
  }

  Widget _buildSearchResults(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _databaseMethods.searchProspectsStream(
        context: context,
        query: query,
        departamento: _selectedDepartamento,
        municipio: _selectedMunicipio,
        direccion: _selectedDireccion,
      ),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text('No se encontraron resultados'));
        }

        return ListView.builder(
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            final doc = snapshot.data!.docs[index];
            final prospect = doc.data() as Map<String, dynamic>;
            final fechaRegistro =
                (prospect['fechaRegistro'] as Timestamp?)?.toDate();

            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: ListTile(
                title: Text(
                  '${prospect['nombre']} ${prospect['apellido']}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Tel: ${prospect['telefono'] ?? 'No especificado'}'),
                    if (fechaRegistro != null)
                      Text(
                        'Registrado: ${DateFormat('dd/MM/yyyy').format(fechaRegistro)}',
                        style: const TextStyle(fontSize: 12),
                      ),
                    if (_selectedDepartamento != null ||
                        prospect['departamento'] != null)
                      Text('Depto: ${prospect['departamento'] ?? ''}'),
                    if (_selectedMunicipio != null ||
                        prospect['municipio'] != null)
                      Text('Muni: ${prospect['municipio'] ?? ''}'),
                  ],
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed:
                          () => _showEditDialog(context, doc.id, prospect),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _confirmDelete(context, doc.id),
                    ),
                  ],
                ),
                onTap: () => _showDetailsDialog(context, prospect),
              ),
            );
          },
        );
      },
    );
  }

  void _showDetailsDialog(BuildContext context, Map<String, dynamic> prospect) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('${prospect['nombre']} ${prospect['apellido']}'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildDetailItem(context, 'Teléfono', prospect['telefono']),
                _buildDetailItem(context, 'Dirección', prospect['direccion']),
                _buildDetailItem(
                  context,
                  'Departamento',
                  prospect['departamento'],
                ),
                _buildDetailItem(context, 'Municipio', prospect['municipio']),
                _buildDetailItem(
                  context,
                  'Tipo de promoción',
                  prospect['tipoPromocion'],
                ),
                if (prospect['tipoPromocion'] == 'Nuevo') ...[
                  _buildDetailItem(
                    context,
                    'Sabía de ADICLA',
                    prospect['sabiaAdicla'],
                  ),
                  _buildDetailItem(
                    context,
                    'Cómo se enteró',
                    prospect['comoSeEntero'],
                  ),
                  _buildDetailItem(context, 'Etapa', prospect['etapa']),
                ],
                if (prospect['tipoPromocion'] == 'Referido')
                  _buildDetailItem(
                    context,
                    'Referido por',
                    prospect['referidoPor'],
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
              child: const Text('Cerrar'),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDetailItem(BuildContext context, String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: RichText(
        text: TextSpan(
          style: DefaultTextStyle.of(context).style,
          children: [
            TextSpan(
              text: '$label: ',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: value ?? 'No especificado'),
          ],
        ),
      ),
    );
  }

  void _showEditDialog(
    BuildContext context,
    String id,
    Map<String, dynamic> prospect,
  ) {
    final formKey = GlobalKey<FormState>();
    final nombreController = TextEditingController(text: prospect['nombre']);
    final apellidoController = TextEditingController(
      text: prospect['apellido'],
    );
    final telefonoController = TextEditingController(
      text: prospect['telefono'],
    );

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Editar Prospecto'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nombreController,
                    decoration: const InputDecoration(labelText: 'Nombre'),
                    validator:
                        (value) => value!.isEmpty ? 'Ingrese el nombre' : null,
                  ),
                  TextFormField(
                    controller: apellidoController,
                    decoration: const InputDecoration(labelText: 'Apellido'),
                    validator:
                        (value) =>
                            value!.isEmpty ? 'Ingrese el apellido' : null,
                  ),
                  TextFormField(
                    controller: telefonoController,
                    decoration: const InputDecoration(labelText: 'Teléfono'),
                    keyboardType: TextInputType.phone,
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.pop(context),
            ),
            ElevatedButton(
              child: const Text('Guardar'),
              onPressed: () async {
                if (formKey.currentState!.validate()) {
                  try {
                    await _databaseMethods.updateProspect(id, {
                      'nombre': nombreController.text,
                      'apellido': apellidoController.text,
                      'telefono': telefonoController.text,
                      'fechaActualizacion': FieldValue.serverTimestamp(),
                    });
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Prospecto actualizado')),
                      );
                      Navigator.pop(context);
                    }
                  } catch (e) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Error: ${e.toString()}')),
                      );
                    }
                  }
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _confirmDelete(BuildContext context, String id) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Confirmar eliminación'),
          content: const Text('¿Estás seguro de eliminar este prospecto?'),
          actions: [
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.pop(context),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Eliminar'),
              onPressed: () async {
                try {
                  await _databaseMethods.deleteProspect(id);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Prospecto eliminado')),
                    );
                    Navigator.pop(context);
                  }
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Error: ${e.toString()}')),
                    );
                  }
                }
              },
            ),
          ],
        );
      },
    );
  }

  Future<Map<String, String?>?> _showAdvancedFilters(
    BuildContext context,
  ) async {
    final departamentos = await _databaseMethods.getDepartamentos();
    final municipios = await _databaseMethods.getMunicipios();

    String? tempDepartamento = _selectedDepartamento;
    String? tempMunicipio = _selectedMunicipio;
    String? tempDireccion = _selectedDireccion;

    final controller = TextEditingController(text: _selectedDireccion);

    return await showDialog<Map<String, String?>>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Filtros Avanzados'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: tempDepartamento,
                      decoration: const InputDecoration(
                        labelText: 'Departamento',
                        border: OutlineInputBorder(),
                      ),
                      items: [
                        const DropdownMenuItem(
                          value: null,
                          child: Text('Todos los departamentos'),
                        ),
                        ...departamentos.map((depto) {
                          return DropdownMenuItem(
                            value: depto,
                            child: Text(depto),
                          );
                        }).toList(),
                      ],
                      onChanged: (value) {
                        setState(() {
                          tempDepartamento = value;
                          tempMunicipio = null;
                        });
                      },
                    ),
                    const SizedBox(height: 16),

                    if (tempDepartamento != null)
                      DropdownButtonFormField<String>(
                        value: tempMunicipio,
                        decoration: const InputDecoration(
                          labelText: 'Municipio',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          const DropdownMenuItem(
                            value: null,
                            child: Text('Todos los municipios'),
                          ),
                          ...municipios
                              .where(
                                (m) => m['departamento'] == tempDepartamento,
                              )
                              .map(
                                (m) => DropdownMenuItem(
                                  value: m['nombre'] as String,
                                  child: Text(m['nombre'] as String),
                                ),
                              )
                              .toList(),
                        ],
                        onChanged: (value) {
                          setState(() {
                            tempMunicipio = value;
                          });
                        },
                      ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: controller,
                      decoration: const InputDecoration(
                        labelText: 'Dirección (contiene)',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (value) {
                        tempDireccion = value.isNotEmpty ? value : null;
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  child: const Text('Limpiar'),
                  onPressed: () {
                    setState(() {
                      tempDepartamento = null;
                      tempMunicipio = null;
                      tempDireccion = null;
                      controller.clear();
                    });
                  },
                ),
                TextButton(
                  child: const Text('Cancelar'),
                  onPressed: () => Navigator.pop(context),
                ),
                ElevatedButton(
                  child: const Text('Aplicar'),
                  onPressed: () {
                    Navigator.pop(context, {
                      'departamento': tempDepartamento,
                      'municipio': tempMunicipio,
                      'direccion': tempDireccion,
                    });
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }
}
