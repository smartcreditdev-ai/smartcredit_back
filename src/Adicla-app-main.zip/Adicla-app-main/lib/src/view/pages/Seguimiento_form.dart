import 'package:adicla/src/provider/auth_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SeguimientoForm extends StatefulWidget {
  const SeguimientoForm({super.key});

  @override
  State<SeguimientoForm> createState() => _SeguimientoFormState();
}

class _SeguimientoFormState extends State<SeguimientoForm> {
  int _currentStep = 0;
  final PageController _pageController = PageController();

  // Controladores para los campos del formulario
  final TextEditingController _observacionesController = TextEditingController();
  final TextEditingController _fechaController = TextEditingController();
  final TextEditingController _correoController = TextEditingController();
  final TextEditingController _numeroSolicitudController = TextEditingController();
  final TextEditingController _fechaLimiteController = TextEditingController();

  // Variables para selecciones
  String? _selectedTipoGestion;
  String? _selectedAsesor;
  String? _selectedEtapa;
  bool _esSecretaria = false; // Ahora se determina por el rol

  // Listas de datos
  List<Map<String, dynamic>> _asesores = [];

  @override
  void initState() {
    super.initState();
    _fechaController.text = DateTime.now().toString().substring(0, 10);
    _fechaLimiteController.text = DateTime.now().add(const Duration(days: 7)).toString().substring(0, 10);
    _cargarAsesores();
    _verificarRolUsuario();
  }

  Future<void> _verificarRolUsuario() async {
    final authService = Provider.of<AuthService>(context, listen: false);
    final user = authService.currentUser;
    
    if (user != null) {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      
      if (userDoc.exists) {
        setState(() {
          _esSecretaria = userDoc.data()?['role'] == 'secretaria';
        });
      }
    }
  }

  Future<void> _cargarAsesores() async {
    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('role', isEqualTo: 'asesor')
          .where('isActive', isEqualTo: true)
          .get();

      setState(() {
        _asesores = querySnapshot.docs.map((doc) {
          return {
            'id': doc.id,
            'nombre': doc.data()['displayName'] ?? 'Sin nombre',
            'email': doc.data()['email'],
          };
        }).toList();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al cargar asesores: ${e.toString()}')),
      );
    }
  }

  @override
  void dispose() {
    _observacionesController.dispose();
    _fechaController.dispose();
    _correoController.dispose();
    _numeroSolicitudController.dispose();
    _fechaLimiteController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  void _nextStep() {
    FocusManager.instance.primaryFocus?.unfocus();

    // Validar el paso actual antes de avanzar
    bool isValid = true;
    switch (_currentStep) {
      case 0:
        if (_selectedTipoGestion == null) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor selecciona el tipo de gestión'),
            ),
          );
        }
        break;
      case 1:
        // Validar etapa para llamada o mensaje
        if ((_selectedTipoGestion == 'llamada' || _selectedTipoGestion == 'mensaje') && 
                 _selectedEtapa == null) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor selecciona la etapa del cliente'),
            ),
          );
        }
        // Validar número de solicitud si está en etapa aprobado
        else if (_selectedEtapa == 'aprobado' && _numeroSolicitudController.text.isEmpty) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor ingresa el número de solicitud'),
            ),
          );
        }
        break;
      case 2:
        if (_selectedTipoGestion == 'visita' && 
            _esSecretaria == true && 
            _selectedAsesor == null) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor selecciona un asesor'),
            ),
          );
        }
        break;
      case 3:
        if (_correoController.text.isEmpty || !_correoController.text.contains('@')) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor ingresa un correo válido'),
            ),
          );
        }
        break;
      case 4:
        if (_observacionesController.text.isEmpty) {
          isValid = false;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Por favor ingresa las observaciones'),
            ),
          );
        }
        break;
    }

    if (!isValid) return;

    // Calcular el número máximo de pasos según el tipo de gestión y rol
    final maxSteps = _getTotalSteps();

    if (_currentStep < maxSteps - 1) {
      setState(() {
        _currentStep++;
        _pageController.nextPage(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      });
    } else {
      _submitForm();
    }
  }

  int _getTotalSteps() {
    if (_selectedTipoGestion == 'visita') {
      return _esSecretaria ? 5 : 4;
    }
    return 4; // Llamada o mensaje tienen 4 pasos
  }

  void _previousStep() {
    FocusManager.instance.primaryFocus?.unfocus();

    if (_currentStep > 0) {
      setState(() {
        _currentStep--;
        _pageController.previousPage(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      });
    }
  }

  void _submitForm() async {
    final authService = Provider.of<AuthService>(context, listen: false);
    final user = authService.currentUser;

    // Crear mapa de datos
    final seguimientoData = {
      'tipoGestion': _selectedTipoGestion,
      'etapa': _selectedEtapa,
      'observaciones': _observacionesController.text,
      'correoCliente': _correoController.text,
      'fecha': FieldValue.serverTimestamp(),
      'creadoPor': user?.displayName ?? 'Desconocido',
      'creadoPorId': user?.uid ?? '',
      'esSecretaria': _esSecretaria,
      'rolUsuario': _esSecretaria ? 'secretaria' : 'otro',
      
      // Agregar fecha límite solo para llamada o mensaje
      if (_selectedTipoGestion == 'llamada' || _selectedTipoGestion == 'mensaje')
        'fechaLimite': DateTime.parse(_fechaLimiteController.text),
      
      if (_selectedTipoGestion == 'visita' && _esSecretaria == true)
        'asesorAsignado': _selectedAsesor,
      
      if (_selectedEtapa == 'aprobado' && _numeroSolicitudController.text.isNotEmpty)
        'numeroSolicitud': _numeroSolicitudController.text,
    };

    try {
      // Mostrar carga
      showDialog(
        context: context,
        barrierDismissible: false,  
        builder: (context) => const Center(child: CircularProgressIndicator()),
      );

      // Guardar en Firebase
      await FirebaseFirestore.instance.collection('seguimientos').add(seguimientoData);

      // Cerrar diálogo y volver
      Navigator.pop(context); // Cierra el loading
      Navigator.pop(context); // Cierra el formulario

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seguimiento registrado exitosamente')),
      );
    } catch (e) {
      Navigator.pop(context); // Cierra el loading si hay error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al guardar: ${e.toString()}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final totalSteps = _getTotalSteps();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Registrar nuevo seguimiento'),
        centerTitle: true,
      ),
      body: GestureDetector(
        onTap: () {
          FocusManager.instance.primaryFocus?.unfocus();
        },
        child: Column(
          children: [
            LinearProgressIndicator(
              value: (_currentStep + 1) / totalSteps,
              backgroundColor: Colors.grey[200],
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color.fromRGBO(51, 67, 139, 1),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Paso ${_currentStep + 1} de $totalSteps',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: _buildSteps(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (_currentStep > 0)
                    ElevatedButton(
                      onPressed: _previousStep,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 12,
                        ),
                      ),
                      child: const Text(
                        'Atrás',
                        style: TextStyle(color: Colors.white),
                      ),
                    )
                  else
                    const SizedBox(width: 100),
                  ElevatedButton(
                    onPressed: _nextStep,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromRGBO(51, 67, 139, 1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                    ),
                    child: Text(
                      _currentStep == totalSteps - 1 ? 'Guardar' : 'Siguiente',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildSteps() {
    final steps = <Widget>[];
    
    // Paso 1: Tipo de gestión (siempre presente)
    steps.add(_buildStep1());
    
    // Paso 2: Depende del tipo de gestión
    if (_selectedTipoGestion == 'visita') {
      if (_esSecretaria) {
        steps.add(_buildStep3()); // Selección de asesor para secretarias
      }
    } else if (_selectedTipoGestion == 'llamada' || _selectedTipoGestion == 'mensaje') {
      steps.add(_buildEtapaStep()); // Etapa para llamadas/mensajes
    }
    
    // Pasos siguientes (correo y observaciones)
    steps.add(_buildCorreoStep());
    steps.add(_buildFinalStep());
    
    return steps;
  }

  Widget _buildStep1() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Tipo de Gestión',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _selectedTipoGestion,
            decoration: const InputDecoration(
              labelText: 'Selecciona el tipo de gestión',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.work_outline),
            ),
            items: const [
              DropdownMenuItem(
                value: 'llamada', child: Text('Llamada telefónica')),
              DropdownMenuItem(value: 'mensaje', child: Text('Mensaje')),
              DropdownMenuItem(value: 'visita', child: Text('Visita presencial')),
            ],
            onChanged: (String? newValue) {
              setState(() {
                _selectedTipoGestion = newValue;
                // Resetear pasos siguientes si cambia el tipo
                if (_currentStep > 0) {
                  _currentStep = 0;
                  _pageController.jumpToPage(0);
                }
              });
            },
          ),
          if (_esSecretaria)
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: Text(
                'Nota: Eres secretaria, por lo que puedes asignar asesores para visitas',
                style: TextStyle(
                  color: Colors.blue[700],
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStep3() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Asignar Asesor',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _selectedAsesor,
            decoration: const InputDecoration(
              labelText: 'Selecciona el asesor a asignar',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person_add),
            ),
            items: _asesores.map((asesor) {
              return DropdownMenuItem<String>(
                value: asesor['id'],
                child: Text('${asesor['nombre']} (${asesor['email']})'),
              );
            }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _selectedAsesor = newValue;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildEtapaStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Etapa del Cliente',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _selectedEtapa,
            decoration: const InputDecoration(
              labelText: 'Selecciona la etapa del cliente',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.timeline),
            ),
            items: const [
              DropdownMenuItem(value: 'no_interesado', child: Text('No interesado')),
              DropdownMenuItem(value: 'no_cumple_requisitos', child: Text('No cumple con los requisitos')),
              DropdownMenuItem(value: 'seguimiento', child: Text('Seguimiento')),
              DropdownMenuItem(value: 'solicitud_generada', child: Text('Solicitud generada')),
              DropdownMenuItem(value: 'rechazado', child: Text('Rechazado')),
              DropdownMenuItem(value: 'aprobado', child: Text('Aprobado')),
            ],
            onChanged: (String? newValue) {
              setState(() {
                _selectedEtapa = newValue;
              });
            },
          ),
          if (_selectedEtapa == 'aprobado') ...[
            const SizedBox(height: 20),
            TextFormField(
              controller: _numeroSolicitudController,
              decoration: const InputDecoration(
                labelText: 'Número de solicitud',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.numbers),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCorreoStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Información del Cliente',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          TextFormField(
            controller: _correoController,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Correo del cliente',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.email),
              hintText: 'ejemplo@dominio.com',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFinalStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Detalles del Seguimiento',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          
          TextFormField(
            controller: _fechaController,
            decoration: const InputDecoration(
              labelText: 'Fecha',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.calendar_today),
              enabled: false,
            ),
          ),
          const SizedBox(height: 16),
          
          if (_selectedTipoGestion == 'llamada' || _selectedTipoGestion == 'mensaje')
            Column(
              children: [
                TextFormField(
                  controller: _fechaLimiteController,
                  decoration: const InputDecoration(
                    labelText: 'Fecha límite de seguimiento',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.calendar_today),
                  ),
                  onTap: () async {
                    final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: DateTime.parse(_fechaLimiteController.text),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (picked != null) {
                      setState(() {
                        _fechaLimiteController.text = picked.toString().substring(0, 10);
                      });
                    }
                  },
                ),
                const SizedBox(height: 16),
              ],
            ),
          
          TextFormField(
            controller: _observacionesController,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: 'Comentarios',
              border: OutlineInputBorder(),
              alignLabelWithHint: true,
            ),
          ),
        ],
      ),
    );
  }
}