import 'package:adicla/src/provider/auth_service.dart';
import 'package:adicla/src/utils/drawer.dart';
import 'package:adicla/src/view/pages/Multi_step_form.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class HomePages extends StatefulWidget {
  const HomePages({super.key});

  @override
  State<HomePages> createState() => _HomePagesState();
}

class _HomePagesState extends State<HomePages> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  late String _userRole;
  late String _userId;

  @override
  void initState() {
    super.initState();
    final authService = Provider.of<AuthService>(context, listen: false);
    _userId = authService.currentUser?.uid ?? '';
    _userRole = authService.currentUser?.role ?? 'asesor';
  }

  // Método para obtener estadísticas de prospectos según rol
  Future<Map<String, dynamic>> _fetchProspectStats() async {
    try {
      QuerySnapshot prospectsSnapshot;

      // Configurar consulta según rol
      if (_userRole == 'asesor') {
        prospectsSnapshot = await _firestore.collection('Prospect')
            .where('asesorId', isEqualTo: _userId)
            .get();
      } else if (_userRole == 'secretaria') {
        // Prospectos de la secretaria
        prospectsSnapshot = await _firestore.collection('Prospect')
            .where('asesorId', isEqualTo: _userId)
            .get();
      } else {
        // Rol no reconocido, mostrar todos los prospectos
        prospectsSnapshot = await _firestore.collection('Prospect').get();
      }

      // Obtener mes actual
      final now = DateTime.now();
      final firstDayOfMonth = DateTime(now.year, now.month, 1);
      
      // Filtrar prospectos del mes actual
      final monthProspects = prospectsSnapshot.docs.where((doc) {
        final data = doc.data() as Map<String, dynamic>;
        final fecha = (data['fechaRegistro'] as Timestamp?)?.toDate();
        return fecha != null && fecha.isAfter(firstDayOfMonth);
      }).toList();

      // Calcular estadísticas por etapa
      final etapas = {
        '1': {'count': 0, 'name': 'Contacto inicial'},
        '2': {'count': 0, 'name': 'Presentación'},
        '3': {'count': 0, 'name': 'Negociación'},
        '4': {'count': 0, 'name': 'Ingresado'},
      };

      for (final doc in prospectsSnapshot.docs) {
        final data = doc.data() as Map<String, dynamic>;
        final etapa = data['etapa']?.toString() ?? '0';
        if (etapas.containsKey(etapa)) {
          etapas[etapa]!['count'] = ((etapas[etapa]!['count'] ?? 0) as int) + 1;
        }
      }

      return {
        'total': prospectsSnapshot.docs.length,
        'mesActual': monthProspects.length,
        'etapas': etapas,
        'seguimiento': (etapas['1']!['count'] as int? ?? 0) + (etapas['2']!['count'] as int? ?? 0) + (etapas['3']!['count'] as int? ?? 0),
        'ingresados': etapas['4']!['count'],
        'conversion': prospectsSnapshot.docs.isNotEmpty 
            ? (((etapas['4']!['count'] ?? 0) as int) / prospectsSnapshot.docs.length * 100).toStringAsFixed(1)
            : '0.0',
      };
    } catch (e) {
      debugPrint('Error al obtener estadísticas: $e');
      return {
        'total': 0,
        'mesActual': 0,
        'etapas': {
          '1': {'count': 0, 'name': 'Contacto inicial'},
          '2': {'count': 0, 'name': 'Presentación'},
          '3': {'count': 0, 'name': 'Negociación'},
          '4': {'count': 0, 'name': 'Ingresado'},
        },
        'seguimiento': 0,
        'ingresados': 0,
        'conversion': '0.0',
      };
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Colors.black),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: const Text(
          'Prospectos',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      drawer: buildDrawer(context),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Welcome section
                  const Text(
                    'Bienvenido',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  
                  // Sección de estadísticas según rol
                  FutureBuilder<Map<String, dynamic>>(
                    future: _fetchProspectStats(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      
                      final stats = snapshot.data ?? {
                        'total': 0,
                        'mesActual': 0,
                        'etapas': {
                          '1': {'count': 0, 'name': 'Contacto inicial'},
                          '2': {'count': 0, 'name': 'Presentación'},
                          '3': {'count': 0, 'name': 'Negociación'},
                          '4': {'count': 0, 'name': 'Ingresado'},
                        },
                        'seguimiento': 0,
                        'ingresados': 0,
                        'conversion': '0.0',
                      };
                      
                      return _userRole == 'secretaria' 
                          ? _buildSecretariaDashboard(stats)
                          : _buildAsesorDashboard(stats);
                    },
                  ),
                  const SizedBox(height: 20),

                  // ADICLA section with button
                  Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'ADICLA',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const MultiStepForm(),
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromRGBO(51, 67, 139, 1),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            minimumSize: const Size(double.infinity, 50),
                          ),
                          child: const Text(
                            'Ingresar Nuevo Prospecto',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // Sección de actividad reciente
                  const SizedBox(height: 20),
                  const Text(
                    'Actividad Reciente',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  _buildRecentActivityList(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
  
  // Dashboard para asesores
  Widget _buildAsesorDashboard(Map<String, dynamic> stats) {
    final etapas = stats['etapas'] as Map<String, Map<String, dynamic>>;
    
    return Column(
      children: [
        // Total de prospectos y del mes
        Row(
          children: [
            _buildStatCard(
              title: 'Total Prospectos',
              value: stats['total'].toString(),
              icon: Icons.people_alt_outlined,
              color: Colors.blue,
            ),
            const SizedBox(width: 10),
            _buildStatCard(
              title: 'Este Mes',
              value: stats['mesActual'].toString(),
              icon: Icons.calendar_month,
              color: Colors.teal,
            ),
          ],
        ),
        const SizedBox(height: 10),
        
        // Seguimiento e ingresados
        Row(
          children: [
            _buildStatCard(
              title: 'En Seguimiento',
              value: stats['seguimiento'].toString(),
              icon: Icons.track_changes,
              color: Colors.orange,
            ),
            const SizedBox(width: 10),
            _buildStatCard(
              title: 'Ingresados',
              value: stats['ingresados'].toString(),
              icon: Icons.check_circle_outline,
              color: Colors.green,
            ),
          ],
        ),
        const SizedBox(height: 10),
        
        // Tasa de conversión
        Center(
          child: SizedBox(
            width: MediaQuery.of(context).size.width * 0.9,
            child: _buildStatCard(
              title: 'Tasa Conversión',
              value: '${stats['conversion']}%',
              icon: Icons.trending_up,
              color: Colors.purple,
            ),
          ),
        ),
        const SizedBox(height: 10),
        
        // Desglose por etapas
        const Text(
          'Desglose por Etapas',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        Column(
          children: [
            _buildEtapaRow('1. Contacto inicial', etapas['1']!['count'].toString(), Colors.blue[200]!),
            _buildEtapaRow('2. Presentación', etapas['2']!['count'].toString(), Colors.orange[200]!),
            _buildEtapaRow('3. Negociación', etapas['3']!['count'].toString(), Colors.yellow[700]!),
            _buildEtapaRow('4. Ingresado', etapas['4']!['count'].toString(), Colors.green[200]!),
          ],
        ),
      ],
    );
  }
  
  // Dashboard para secretarias
  Widget _buildSecretariaDashboard(Map<String, dynamic> stats) {
    final etapas = stats['etapas'] as Map<String, Map<String, dynamic>>;
    
    return Column(
      children: [
        // Título sección personal
        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Mis Prospectos',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(height: 10),
        
        // Mis prospectos - total y mes
        Row(
          children: [
            _buildStatCard(
              title: 'Mis Prospectos',
              value: stats['total'].toString(),
              icon: Icons.people_alt_outlined,
              color: Colors.blue,
            ),
            const SizedBox(width: 10),
            _buildStatCard(
              title: 'Este Mes',
              value: stats['mesActual'].toString(),
              icon: Icons.calendar_month,
              color: Colors.teal,
            ),
          ],
        ),
        const SizedBox(height: 10),
        
        // Mis prospectos - seguimiento e ingresados
        Row(
          children: [
            _buildStatCard(
              title: 'En Seguimiento',
              value: stats['seguimiento'].toString(),
              icon: Icons.track_changes,
              color: Colors.orange,
            ),
            const SizedBox(width: 10),
            _buildStatCard(
              title: 'Ingresados',
              value: stats['ingresados'].toString(),
              icon: Icons.check_circle_outline,
              color: Colors.green,
            ),
          ],
        ),
        const SizedBox(height: 10),
        
        // Desglose mis prospectos por etapas
        const Text(
          'Mis Prospectos por Etapas',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        Column(
          children: [
            _buildEtapaRow('1. Contacto inicial', etapas['1']!['count'].toString(), Colors.blue[200]!),
            _buildEtapaRow('2. Presentación', etapas['2']!['count'].toString(), Colors.orange[200]!),
            _buildEtapaRow('3. Negociación', etapas['3']!['count'].toString(), Colors.yellow[700]!),
            _buildEtapaRow('4. Ingresado', etapas['4']!['count'].toString(), Colors.green[200]!),
          ],
        ),
      ],
    );
  }
  
  // Widget para construir tarjetas de estadísticas
  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Card(
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(icon, color: color, size: 30),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  // Widget para filas de etapas
  Widget _buildEtapaRow(String title, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: const TextStyle(fontSize: 14)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  // Widget para mostrar actividad reciente
  Widget _buildRecentActivityList() {
    Query query = _firestore.collection('Prospect')
        .orderBy('fechaRegistro', descending: true)
        .limit(5);
    
    // Filtrar por usuario si no es admin
    if (_userRole == 'asesor') {
      query = query.where('asesorId', isEqualTo: _userId);
    }
    
    return StreamBuilder<QuerySnapshot>(
      stream: query.snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text('No hay actividad reciente'));
        }
        
        final docs = snapshot.data!.docs;
        
        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: docs.length,
          itemBuilder: (context, index) {
            final data = docs[index].data() as Map<String, dynamic>;
            final nombre = data['nombre'] ?? 'Prospecto';
            final apellido = data['apellido'] ?? '';
            final etapa = data['etapa'] ?? '0';
            final fechaRegistro = (data['fechaRegistro'] as Timestamp?)?.toDate();
            
            String etapaText;
            switch (etapa) {
              case '1':
                etapaText = 'Contacto inicial';
                break;
              case '2':
                etapaText = 'Presentación';
                break;
              case '3':
                etapaText = 'Negociación';
                break;
              case '4':
                etapaText = 'Ingresado';
                break;
              default:
                etapaText = 'Nuevo';
            }
            
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.blue[100],
                  child: Text(nombre[0].toUpperCase()),
                ),
                title: Text('$nombre $apellido'),
                subtitle: Text(etapaText),
                trailing: fechaRegistro != null 
                    ? Text(DateFormat('dd/MM').format(fechaRegistro))
                    : const Text('--/--'),
              ),
            );
          },
        );
      },
    );
  }
}