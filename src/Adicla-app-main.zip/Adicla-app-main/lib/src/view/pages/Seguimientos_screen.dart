import 'package:adicla/src/provider/auth_service.dart';
import 'package:adicla/src/view/pages/Seguimiento_form.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class SeguimientosScreen extends StatefulWidget {
  const SeguimientosScreen({super.key});

  @override
  State<SeguimientosScreen> createState() => _SeguimientosScreenState();
}

class _SeguimientosScreenState extends State<SeguimientosScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController _searchController = TextEditingController();
  String _searchText = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context, listen: false);
    final currentUserId = authService.currentUser?.uid;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestión de Seguimientos'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SeguimientoForm(),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Buscar por nombre, correo o solicitud',
                prefixIcon: const Icon(Icons.search),
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchText = '';
                    });
                  },
                ),
              ),
              onChanged: (value) {
                setState(() {
                  _searchText = value.toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              // Modificado para filtrar por creadoPorId
              stream: _firestore
                  .collection('seguimientos')
                  .where('creadoPorId', isEqualTo: currentUserId)
                  .orderBy('fecha', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final seguimientos = snapshot.data!.docs.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  final nombre =
                      data['nombreCliente']?.toString().toLowerCase() ?? '';
                  final correo =
                      data['correoCliente']?.toString().toLowerCase() ?? '';
                  final solicitud =
                      data['numeroSolicitud']?.toString().toLowerCase() ?? '';
                  final observaciones =
                      data['observaciones']?.toString().toLowerCase() ?? '';
                  return nombre.contains(_searchText) ||
                      correo.contains(_searchText) ||
                      solicitud.contains(_searchText) ||
                      observaciones.contains(_searchText);
                }).toList();

                if (seguimientos.isEmpty) {
                  return const Center(
                    child: Text('No hay seguimientos registrados'),
                  );
                }

                return ListView.builder(
                  itemCount: seguimientos.length,
                  itemBuilder: (context, index) {
                    final doc = seguimientos[index];
                    final data = doc.data() as Map<String, dynamic>;
                    final fecha = data['fecha'] as Timestamp?;
                    final fechaFormateada = fecha != null
                        ? DateFormat('dd/MM/yyyy HH:mm').format(fecha.toDate())
                        : 'Sin fecha';

                    return Card(
                      elevation: 2,
                      margin: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ExpansionTile(
                        tilePadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        childrenPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        title: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: Colors.blue.shade100,
                              child: Icon(
                                Icons.person,
                                color: Colors.blue.shade700,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    data['nombreCliente'] ??
                                        data['correoCliente'] ??
                                        'Sin nombre',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                  Text(
                                    'Tipo: ${data['tipoGestion'] ?? 'Desconocido'}',
                                    style: TextStyle(
                                      color: Colors.grey.shade700,
                                      fontSize: 13,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            // Botones SIEMPRE visibles (ya que solo son los del usuario actual)
                            IconButton(
                              icon: const Icon(
                                Icons.edit,
                                color: Colors.blue,
                              ),
                              tooltip: 'Actualizar',
                              onPressed: () => _showEditDialog(doc),
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.delete,
                                color: Colors.red,
                              ),
                              tooltip: 'Eliminar',
                              onPressed: () => _confirmDelete(doc),
                            ),
                          ],
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 4.0),
                          child: Row(
                            children: [
                              Icon(
                                Icons.calendar_today,
                                size: 14,
                                color: Colors.grey,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                fechaFormateada,
                                style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 13,
                                ),
                              ),
                              if (data['etapa'] != null) ...[
                                const SizedBox(width: 12),
                                Icon(Icons.flag, size: 14, color: Colors.grey),
                                const SizedBox(width: 4),
                                Text(
                                  data['etapa'],
                                  style: TextStyle(
                                    color: Colors.grey.shade600,
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        children: [
                          Divider(),
                          _infoRow('Correo', data['correoCliente']),
                          _infoRow('Solicitud', data['numeroSolicitud']),
                          _infoRow('Asesor asignado', data['asesorAsignado']),
                          _infoRow(
                            'Es secretaria',
                            data['esSecretaria'] == true ? 'Sí' : 'No',
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Observaciones:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(data['observaciones'] ?? 'No hay observaciones'),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // Helper para mostrar filas de información solo si existe el dato
  Widget _infoRow(String label, dynamic value) {
    if (value == null || value.toString().isEmpty) return SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 4.0),
      child: Row(
        children: [
          Text('$label: ', style: TextStyle(fontWeight: FontWeight.w500)),
          Expanded(child: Text(value.toString())),
        ],
      ),
    );
  }

  void _showEditDialog(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final observacionesController = TextEditingController(
      text: data['observaciones'],
    );
    final correoController = TextEditingController(text: data['correoCliente']);
    final nombreController = TextEditingController(
      text: data['nombreCliente'] ?? '',
    );
    final numeroSolicitudController = TextEditingController(
      text: data['numeroSolicitud'] ?? '',
    );

    String? selectedTipoGestion = data['tipoGestion'];
    bool? esSecretaria = data['esSecretaria'];
    String? selectedAsesor = data['asesorAsignado'];
    String? selectedEtapa = data['etapa'];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('Editar Seguimiento'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nombreController,
                    decoration: const InputDecoration(
                      labelText: 'Nombre del cliente',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: correoController,
                    decoration: const InputDecoration(
                      labelText: 'Correo del cliente',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: selectedTipoGestion,
                    decoration: const InputDecoration(
                      labelText: 'Tipo de gestión',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: 'llamada',
                        child: Text('Llamada telefónica'),
                      ),
                      DropdownMenuItem(
                        value: 'mensaje',
                        child: Text('Mensaje'),
                      ),
                      DropdownMenuItem(
                        value: 'visita',
                        child: Text('Visita presencial'),
                      ),
                    ],
                    onChanged: (String? newValue) {
                      setState(() {
                        selectedTipoGestion = newValue;
                      });
                    },
                  ),
                  const SizedBox(height: 16),
                  if (selectedTipoGestion == 'llamada' ||
                      selectedTipoGestion == 'mensaje')
                    DropdownButtonFormField<String>(
                      value: selectedEtapa,
                      decoration: const InputDecoration(
                        labelText: 'Etapa del cliente',
                        border: OutlineInputBorder(),
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: 'no_interesado',
                          child: Text('No interesado'),
                        ),
                        DropdownMenuItem(
                          value: 'no_cumple_requisitos',
                          child: Text('No cumple requisitos'),
                        ),
                        DropdownMenuItem(
                          value: 'seguimiento',
                          child: Text('Seguimiento'),
                        ),
                        DropdownMenuItem(
                          value: 'solicitud_generada',
                          child: Text('Solicitud generada'),
                        ),
                        DropdownMenuItem(
                          value: 'rechazado',
                          child: Text('Rechazado'),
                        ),
                        DropdownMenuItem(
                          value: 'aprobado',
                          child: Text('Aprobado'),
                        ),
                      ],
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedEtapa = newValue;
                        });
                      },
                    ),
                  if (selectedTipoGestion == 'visita') ...[
                    const SizedBox(height: 16),
                    const Text('¿Eres secretaria?'),
                    Row(
                      children: [
                        Radio<bool>(
                          value: true,
                          groupValue: esSecretaria,
                          onChanged: (bool? value) {
                            setState(() {
                              esSecretaria = value;
                            });
                          },
                        ),
                        const Text('Sí'),
                        Radio<bool>(
                          value: false,
                          groupValue: esSecretaria,
                          onChanged: (bool? value) {
                            setState(() {
                              esSecretaria = value;
                            });
                          },
                        ),
                        const Text('No'),
                      ],
                    ),
                  ],
                  if (selectedEtapa == 'aprobado') ...[
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: numeroSolicitudController,
                      decoration: const InputDecoration(
                        labelText: 'Número de solicitud',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: observacionesController,
                    maxLines: 5,
                    decoration: const InputDecoration(
                      labelText: 'Observaciones',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancelar'),
              ),
              ElevatedButton(
                onPressed: () async {
                  final updatedData = {
                    'nombreCliente': nombreController.text,
                    'correoCliente': correoController.text,
                    'tipoGestion': selectedTipoGestion,
                    'etapa': selectedEtapa,
                    'observaciones': observacionesController.text,
                    'esSecretaria': esSecretaria,
                    'asesorAsignado': selectedAsesor,
                    'numeroSolicitud':
                        numeroSolicitudController.text.isNotEmpty
                            ? numeroSolicitudController.text
                            : null,
                    'ultimaActualizacion': FieldValue.serverTimestamp(),
                  };

                  try {
                    await doc.reference.update(updatedData);
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Seguimiento actualizado correctamente',
                        ),
                      ),
                    );
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Error al actualizar: ${e.toString()}',
                        ),
                      ),
                    );
                  }
                },
                child: const Text('Guardar'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _confirmDelete(DocumentSnapshot doc) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar eliminación'),
        content: const Text(
          '¿Estás seguro de que quieres eliminar este seguimiento? Esta acción no se puede deshacer.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text(
              'Eliminar',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await doc.reference.delete();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Seguimiento eliminado correctamente')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al eliminar: ${e.toString()}')),
        );
      }
    }
  }
}