import 'package:adicla/src/view/auth/login_view.dart';
import 'package:flutter/material.dart';

class AnimatedCortinaSplash extends StatefulWidget {
  const AnimatedCortinaSplash({super.key});

  @override
  State<AnimatedCortinaSplash> createState() => _AnimatedCortinaSplashState();
}

class _AnimatedCortinaSplashState extends State<AnimatedCortinaSplash> {
  bool isBackLogin = true;
  initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      isBackLogin = false;

      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return isBackLogin
        ? Scaffold(
          backgroundColor: Colors.white,
          body: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 64),
              Center(child: Image.asset('assets/images/logo_new.png')),
            ],
          ),
        )
        : const LoginScreen();
  }
}
