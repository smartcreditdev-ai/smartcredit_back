import 'package:flutter/material.dart';

class AuthenticatedUser with ChangeNotifier {
  int? id;
  List<int>? companyIds; // Cambiado de int? company_id a List<int>? companyIds
  int? company_id;
  String? name;
  String? lastname;
  String? document;
  String? charge;
  String? username;
  String? genero;
  String? email;
  String? email_verified_at;
  String? password;
  String? phone;
  String? status;
  String? image;
  String? remember_token;
  String? deleted_at;
  String? created_at;
  String? updated_at;

  // Método para actualizar la información del usuario
  void updateUser({
    int? id,
    List<int>?
        companyIds, // Cambiado de int? company_id a List<int>? companyIds
    int? company_id,
    String? name,
    String? lastname,
    String? document,
    String? charge,
    String? username,
    String? genero,
    String? email,
    String? email_verified_at,
    String? password,
    String? phone,
    String? status,
    String? image,
    String? remember_token,
    String? deleted_at,
    String? created_at,
    String? updated_at,
  }) {
    this.id = id;
    this.companyIds =
        companyIds ?? this.companyIds; // Cambiado de company_id a companyIds
    this.company_id = company_id;
    this.name = name;
    this.lastname = lastname;
    this.document = document;
    this.charge = charge;
    this.username = username;
    this.genero = genero;
    this.email = email;
    this.email_verified_at = email_verified_at;
    this.password = password;
    this.phone = phone;
    this.status = status;
    this.image = image;
    this.remember_token = remember_token;
    this.created_at = created_at;
    this.updated_at = updated_at;
    this.deleted_at = deleted_at;
    notifyListeners();
  }

  bool _isAuthenticated =
      false; // Variable para controlar si el usuario está autenticado
  bool get isAuthenticated => _isAuthenticated;

  // Método para actualizar el estado de autenticación
  void setAuthenticationStatus(bool status) {
    _isAuthenticated = status;
    notifyListeners();
  }
}
