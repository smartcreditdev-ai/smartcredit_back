import 'package:adicla/src/admin/view/home_admin_views.dart';
import 'package:adicla/src/provider/auth_service.dart';
import 'package:adicla/src/utils/helpers.dart';
import 'package:adicla/src/utils/utils.dart';
import 'package:adicla/src/view/auth/password_recovery_view.dart';
import 'package:adicla/src/view/auth/register_view.dart';
import 'package:adicla/src/view/pages/home_pages.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class LoginScreen extends StatefulWidget {
  static const routeName = "/loginScreen";

  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  bool _obscurePassword = true;
  //controladores
  final _userController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    _userController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  //login
  validateForm() {
    if (_userController.text.isEmpty) {
      Fluttertoast.showToast(msg: "El usuario es requerido...");
    } else if (_passwordController.text.isEmpty) {
      Fluttertoast.showToast(msg: "La contraseña es requerida...");
    } else {
      _login();
    }
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    final email = _userController.text.trim();
    final password = _passwordController.text.trim();

    try {
      final userDoc =
          await FirebaseFirestore.instance
              .collection('users')
              .where('email', isEqualTo: email)
              .limit(1)
              .get();

      if (userDoc.docs.isEmpty) {
        setState(() => _isLoading = false);
        showSnackBar(context, 'Usuario no encontrado');
        return;
      }

      final userData = userDoc.docs.first.data();
      final userRef = userDoc.docs.first.reference;

      if (userData['approvedByAdmin'] == false) {
        setState(() => _isLoading = false);
        showDialog(
          context: context,
          builder:
              (_) => AlertDialog(
                title: Text('Cuenta pendiente de activación'),
                content: Text(
                  'Tu cuenta aún no ha sido activada por un administrador. Por favor, espera la aprobación.',
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: Text('OK'),
                  ),
                ],
              ),
        );
        return;
      }

      // Si el usuario fue desactivado por intentos fallidos
      if (userData['isActive'] == false) {
        setState(() => _isLoading = false);
        showDialog(
          context: context,
          builder:
              (_) => AlertDialog(
                title: Text('Cuenta inactiva'),
                content: Text(
                  'Tu cuenta ha sido desactivada por múltiples intentos fallidos. Contacta al administrador.',
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: Text('OK'),
                  ),
                ],
              ),
        );
        return;
      }

      // Intento de login
      final authService = Provider.of<AuthService>(context, listen: false);
      final user = await authService.signInWithEmailAndPassword(
        email,
        password,
      );

      // Resetear intentos fallidos al iniciar sesión correctamente
      await userRef.update({'failedAttempts': 0});

      setState(() => _isLoading = false);

      // Navegar según rol
      Widget destination;
      switch (user?.role) {
        case 'admin':
          destination = AdminHomeScreen();
          break;
        case 'secretaria':
        case 'asesor':
          destination = HomePages();
          break;
        default:
          destination = HomePages();
      }

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => destination),
        (Route<dynamic> route) => false,
      );
    } on FirebaseAuthException catch (e) {
      setState(() => _isLoading = false);

      if (e.code == 'wrong-password') {
        // Si el usuario existe, incrementar intentos fallidos
        final userDoc =
            await FirebaseFirestore.instance
                .collection('users')
                .where('email', isEqualTo: email)
                .limit(1)
                .get();

        if (userDoc.docs.isNotEmpty) {
          final userRef = userDoc.docs.first.reference;
          final userData = userDoc.docs.first.data();
          int failedAttempts = (userData['failedAttempts'] ?? 0) + 1;

          if (failedAttempts >= 3) {
            // Desactivar cuenta
            await userRef.update({
              'failedAttempts': failedAttempts,
              'isActive': false,
            });

            showDialog(
              context: context,
              builder:
                  (_) => AlertDialog(
                    title: Text('Cuenta desactivada'),
                    content: Text(
                      'Has excedido el número de intentos permitidos. Tu cuenta ha sido desactivada.',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: Text('OK'),
                      ),
                    ],
                  ),
            );
          } else {
            // Solo aumentar el contador
            await userRef.update({'failedAttempts': failedAttempts});
            showSnackBar(
              context,
              'Contraseña incorrecta. Intento $failedAttempts de 3',
            );
          }
        }
      } else {
        showSnackBar(context, 'Error: ${e.message}');
      }
    } catch (e) {
      setState(() => _isLoading = false);
      showSnackBar(context, 'Error inesperado al iniciar sesión');
    }
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    var paddingHorizontal = size.width * 0.1;
    var paddingVertical = size.height * 0.05;

    return Scaffold(
      bottomNavigationBar: UI.getNombreAgencia(),
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.symmetric(
            horizontal: paddingHorizontal,
            vertical: paddingVertical,
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Image.asset(
                  "assets/images/logo_new.png",
                  width: size.width * 0.6,
                ),
                const SizedBox(height: 20),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(width: 10),
                      Text(
                        'Bienvenido',
                        style: TextStyle(
                          color: Colors.black,
                          fontFamily: "SanFrancisco_Italic",
                          fontSize: 25,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 26, bottom: 10),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        TextFormField(
                          controller: _userController,
                          validator:
                              (val) => val == "" ? "Escriba su usuario" : null,
                          decoration: UI().textInputDecoration(
                            UI.getIcon("personBorder", Colors.grey, null),
                            "Usuario",
                          ),
                          keyboardType: TextInputType.emailAddress,
                        ),
                        const SizedBox(height: 25),
                        TextFormField(
                          controller: _passwordController,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.white,
                            labelText: 'Contraseña',
                            //prefixIcon: Icon(Icons.lock),
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscurePassword
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                              ),
                              onPressed:
                                  () => setState(
                                    () => _obscurePassword = !_obscurePassword,
                                  ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          obscureText: _obscurePassword,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Por favor ingresa tu contraseña';
                            }
                            if (value.length < 6) {
                              return 'La contraseña debe tener al menos 6 caracteres';
                            }
                            return null;
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                UI.getButton("Ingresar", 20, size.width * 0.9, 50, () {
                  if (_formKey.currentState!.validate()) {
                    //validateForm();
                    _login();
                  }
                }),
                const SizedBox(height: 200),
                _getTextRich(context),
                const SizedBox(height: 10),
                _getTextPasswordRich(context),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _getTextRich(BuildContext context) {
    return Text.rich(
      TextSpan(
        children: <TextSpan>[
          const TextSpan(
            text: '¿No tienes una cuenta?  ',
            style: TextStyle(fontFamily: "SanFrancisco_Bold", fontSize: 14),
          ),
          TextSpan(
            text: 'registrate',
            recognizer:
                TapGestureRecognizer()
                  ..onTap = () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => RegisterScreen()),
                    );
                  },
            style: TextStyle(
              color: Color.fromRGBO(51, 67, 139, 2),
              fontFamily: "SanFrancisco_Bold",
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  _getTextPasswordRich(BuildContext context) {
    return Text.rich(
      TextSpan(
        children: <TextSpan>[
          const TextSpan(
            text: '¿Olvidaste tu contraseña?  ',
            style: TextStyle(fontFamily: "SanFrancisco_Bold", fontSize: 14),
          ),
          TextSpan(
            text: 'recuperar',
            recognizer:
                TapGestureRecognizer()
                  ..onTap = () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const PasswordRecoveryScreen(),
                      ),
                    );
                  },
            style: TextStyle(
              color: Color.fromRGBO(51, 67, 139, 2),
              fontFamily: "SanFrancisco_Bold",
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}
