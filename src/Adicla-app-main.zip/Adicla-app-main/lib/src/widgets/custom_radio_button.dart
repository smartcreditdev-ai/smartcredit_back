import 'package:adicla/src/utils/color_constant.dart';
import 'package:adicla/src/utils/size_utils.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class CustomRadioButton extends StatelessWidget {
  CustomRadioButton({
    this.fontStyle,
    this.alignment,
    this.onChange,
    this.isRightCheck = false,
    this.iconSize,
    this.value,
    this.groupValue,
    this.text,
    this.width,
    this.margin,
  });

  RadioFontStyle? fontStyle;

  Alignment? alignment;

  Function(String)? onChange;

  bool? isRightCheck;

  double? iconSize;

  String? value;

  String? groupValue;

  String? text;

  double? width;

  EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
          alignment: alignment ?? Alignment.center,
          child: _buildRadioButtonWidget(),
        )
        : _buildRadioButtonWidget();
  }

  _buildRadioButtonWidget() {
    return InkWell(
      onTap: () {
        onChange!(value!);
      },
      child: Container(
        width: width,
        margin: margin ?? EdgeInsets.zero,
        child: isRightCheck! ? getRightSideRadio() : getLeftSideRadio(),
      ),
    );
  }

  Widget getRightSideRadio() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(padding: EdgeInsets.only(right: 8), child: getTextWidget()),
        getRadioWidget(),
      ],
    );
  }

  Widget getLeftSideRadio() {
    return Row(
      children: [
        getRadioWidget(),
        Padding(padding: EdgeInsets.only(left: 8), child: getTextWidget()),
      ],
    );
  }

  Widget getTextWidget() {
    return Text(
      text ?? "",
      textAlign: TextAlign.center,
      style: _setFontStyle(),
    );
  }

  Widget getRadioWidget() {
    return SizedBox(
      height: iconSize,
      width: iconSize,
      child: Radio<String>(
        value: value ?? "",
        groupValue: groupValue,
        activeColor: ColorConstant.fromHex("#e5f39022"),
        onChanged: (value) {
          onChange!(value!);
        },
        visualDensity: VisualDensity(vertical: -4, horizontal: -4),
      ),
    );
  }

  _setFontStyle() {
    switch (fontStyle) {
      case RadioFontStyle.PoppinsMedium12:
        return TextStyle(
          color: ColorConstant.black900,
          fontSize: getFontSize(12),
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w500,
          height: getVerticalSize(1.50),
        );
      case RadioFontStyle.RobotoMedium12:
        return TextStyle(
          color: ColorConstant.black900,
          fontSize: getFontSize(12),
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w500,
          height: getVerticalSize(1.25),
        );
      case RadioFontStyle.RobotoRegular12:
        return TextStyle(
          color: ColorConstant.black900,
          fontSize: getFontSize(12),
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
          height: getVerticalSize(1.25),
        );
      default:
        return TextStyle(
          color: ColorConstant.black900A2,
          fontSize: getFontSize(14),
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
          height: getVerticalSize(1.21),
        );
    }
  }
}

enum RadioFontStyle {
  RobotoRegular14,
  PoppinsMedium12,
  RobotoMedium12,
  RobotoRegular12,
}
