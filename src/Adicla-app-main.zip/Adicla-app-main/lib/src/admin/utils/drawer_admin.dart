import 'package:adicla/src/provider/auth_service.dart';
import 'package:adicla/src/view/auth/login_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

Widget buildAdminDrawer(BuildContext context, Function(int) onSelectItem) {
  final authService = Provider.of<AuthService>(context);
  final user = authService.currentUser;

  return Drawer(
    child: ListView(
      padding: EdgeInsets.zero,
      children: [
        _buildDrawerHeader(
          name: user?.displayName ?? 'Sin nombre',
          email: user?.email ?? 'Sin correo',
          photoUrl: user?.photoUrl,
        ),
        _buildDrawerItem(
          icon: Icons.dashboard,
          title: 'Resumen',
          index: 0,
          onTap: onSelectItem,
        ),
        _buildDrawerItem(
          icon: Icons.people,
          title: 'Usuarios',
          index: 1,
          onTap: onSelectItem,
        ),
        _buildDrawerItem(
          icon: Icons.assignment,
          title: 'Prospectos',
          index: 2,
          onTap: onSelectItem,
        ),
        const Divider(),
        _buildDrawerItem(
          icon: Icons.settings,
          title: 'Rotativos',
          index: 3,
          onTap: onSelectItem,
        ),
        /*_buildDrawerItem(
          icon: Icons.help,
          title: 'Ayuda',
          index: 4,
          onTap: onSelectItem,
        ),*/
        const Divider(),
        ListTile(
          leading: const Icon(Icons.exit_to_app),
          title: const Text('Cerrar Sesión'),
          onTap: () async {
            Navigator.pop(context);
            try {
              await authService.signOut();
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                (_) => false,
              );
            } catch (error) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Error al cerrar sesión: $error')),
              );
            }
          },
        ),
      ],
    ),
  );
}

Widget _buildDrawerHeader({
  required String name,
  required String email,
  String? photoUrl,
}) {
  return UserAccountsDrawerHeader(
    accountName: Text(name),
    accountEmail: Text(email),
    currentAccountPicture: CircleAvatar(
      backgroundImage:
          photoUrl != null
              ? NetworkImage(photoUrl)
              : NetworkImage('https://randomuser.me/api/portraits/men/41.jpg'),
    ),
    decoration: const BoxDecoration(color: Color(0xFF33438B)),
  );
}

Widget _buildDrawerItem({
  required IconData icon,
  required String title,
  required int index,
  required Function(int) onTap,
}) {
  return ListTile(
    leading: Icon(icon),
    title: Text(title),
    onTap: () => onTap(index), // Notifica el índice
  );
}
