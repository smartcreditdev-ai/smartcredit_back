import 'package:adicla/src/admin/services/create_user_admin.dart';
import 'package:adicla/src/admin/services/edit_user.dart';
import 'package:adicla/src/admin/services/edit_user_admin.dart';
import 'package:adicla/src/admin/utils/drawer_admin.dart';
import 'package:adicla/src/provider/auth_service.dart';
import 'package:adicla/src/services/prospects.dart';
import 'package:adicla/src/view/pages/prospects_view.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:provider/provider.dart';

class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({super.key});

  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int _currentPageIndex = 0;

  final List<String> _pageTitles = [
    'Inicio',
    'Usuarios',
    'Prospectos',
    'Rotativos',
    // 'Ayuda',
  ];

  final List<Widget> _pages = [const AdminHomeScreen()];

  Future<Map<String, int>> _fetchCountsFromFirestore() async {
    final usersSnapshot =
        await FirebaseFirestore.instance.collection('users').get();
    final prospectsSnapshot =
        await FirebaseFirestore.instance.collection('Prospect').get();

    return {
      'users': usersSnapshot.docs.length,
      'prospects': prospectsSnapshot.docs.length,
    };
  }

  void _onSelectDrawerItem(int index) {
    setState(() {
      _currentPageIndex = index;
    });
    Navigator.pop(context); // Cierra el drawer
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context, listen: false);
    final currentUserId = authService.currentUser?.uid;
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text(_pageTitles[_currentPageIndex]),
        actions: [
          //IconButton(icon: const Icon(Icons.notifications), onPressed: () {}),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8.0),
            child: CircleAvatar(
              backgroundImage: NetworkImage(
                'https://randomuser.me/api/portraits/men/41.jpg',
              ),
            ),
          ),
        ],
      ),
      drawer: buildAdminDrawer(context, _onSelectDrawerItem),
      body: buildCurrentPage(),
      floatingActionButton:
          _currentPageIndex == 1
              ? FloatingActionButton(
                onPressed: () => showAddUserDialog(context),
                child: const Icon(Icons.add),
              )
              : null,
    );
  }

  Widget buildCurrentPage() {
    final authService = Provider.of<AuthService>(context, listen: false);
    final currentUserId = authService.currentUser?.uid;
    switch (_currentPageIndex) {
      case 0:
        return _buildDashboard();
      case 1:
        return _buildUsersPage();
      case 2:
        return _buildProspectsPage(currentUserId);
      case 3:
        return _buildUsersRotativePage();
      /*case 4:
        return _buildHelpPage();*/
      default:
        return _buildDashboard();
    }
  }

  Widget _buildDashboard() {
    return FutureBuilder<Map<String, int>>(
      future: _fetchCountsFromFirestore(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return const Center(child: Text('Error al cargar los datos'));
        }

        final counts = snapshot.data!;
        final userCount = counts['users'] ?? 0;
        final prospectCount = counts['prospects'] ?? 0;

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Resumen del Sistema',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  _buildStatCard(
                    title: 'Usuarios',
                    value: '$userCount',
                    icon: Icons.people,
                    color: Colors.blue,
                  ),
                  const SizedBox(width: 16),
                  _buildStatCard(
                    title: 'Prospectos',
                    value: '$prospectCount',
                    icon: Icons.assignment,
                    color: Colors.green,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  _buildStatCard(
                    title: 'Activos',
                    value: '89%',
                    icon: Icons.check_circle,
                    color: Colors.orange,
                  ),
                  const SizedBox(width: 16),
                  _buildStatCard(
                    title: 'Conversión',
                    value: '4%',
                    icon: Icons.trending_up,
                    color: Colors.purple,
                  ),
                ],
              ),
              const SizedBox(height: 24),
              const Text(
                'Actividad Reciente',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              _buildActivityList(),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Expanded(
      child: Card(
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color, size: 40),
              const SizedBox(height: 10),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                title,
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActivityList() {
    return StreamBuilder<QuerySnapshot>(
      stream:
          FirebaseFirestore.instance
              .collection('Prospect')
              .orderBy('fechaRegistro', descending: true)
              .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text('No hay actividades recientes.'));
        }

        final docs = snapshot.data!.docs;

        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: docs.length,
          itemBuilder: (context, index) {
            final data = docs[index].data() as Map<String, dynamic>;
            final asesor = data['asesor'] ?? 'Asesor desconocido';
            final fechaRegistro =
                (data['fechaRegistro'] as Timestamp?)?.toDate();
            final nombre = data['nombre'] ?? 'Prospecto';

            final timeAgo =
                fechaRegistro != null
                    ? timeago.format(fechaRegistro, locale: 'es')
                    : 'Sin fecha';

            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundImage: NetworkImage(
                    'https://randomuser.me/api/portraits/men/${index + 10}.jpg',
                  ),
                ),
                title: Text(asesor),
                subtitle: Text('Creó un prospecto: $nombre'),
                trailing: Text(
                  timeAgo,
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildUsersPage() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('Error al cargar usuarios'));
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        final users = snapshot.data!.docs;

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: users.length,
          itemBuilder: (context, index) {
            final user = users[index];
            final data = user.data() as Map<String, dynamic>;
            final email = data['email'] ?? 'Sin email';
            final role = data['role'] ?? 'Usuario';
            final status = data['isActive'] == true ? 'Activo' : 'Inactivo';
            final isActive = data['isActive'] == true;
            final selectdIsAdmin = data['selectdIsAdmin'] == true;

            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.blue[100],
                  child: Text(email[0].toUpperCase()),
                ),
                title: Text(email),
                subtitle: Text('$role • $status'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed:
                          () => editUser(
                            context,
                            user.id,
                            email,
                            role,
                            isActive,
                            selectdIsAdmin,
                          ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deleteUser(user.id),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildUsersRotativePage() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('Error al cargar usuarios'));
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        final users =
            snapshot.data!.docs
                .where(
                  (doc) =>
                      (doc.data() as Map<String, dynamic>)['role'] ==
                      'secretaria',
                )
                .toList();

        if (users.isEmpty) {
          return const Center(child: Text('No hay secretarias registradas'));
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: users.length,
          itemBuilder: (context, index) {
            final user = users[index];
            final data = user.data() as Map<String, dynamic>;
            final email = data['email'] ?? 'Sin email';
            final role = data['role'] ?? 'Usuario';
            final status = data['isActive'] == true ? 'Activo' : 'Inactivo';
            final isActive = data['isActive'] == true;
            final selectdIsAdmin = data['selectdIsAdmin'] == true;
            final agencia = data['agencia'] ?? 'principal';

            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.blue[100],
                  child: Text(email[0].toUpperCase()),
                ),
                title: Text(email),
                subtitle: Text('$role • $status'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed:
                          () => editUserRotative(
                            context,
                            user.id,
                            email,
                            role,
                            agencia,
                            isActive,
                            selectdIsAdmin,
                          ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deleteUser(user.id),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _deleteUser(String userId) {
    // Implementar lógica de eliminación
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Eliminar Usuario'),
          content: const Text('¿Estás seguro de eliminar este usuario?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            TextButton(
              onPressed: () {
                // Eliminar usuario de Firestore
                FirebaseFirestore.instance
                    .collection('users')
                    .doc(userId)
                    .delete();
                Navigator.pop(context);
              },
              child: const Text(
                'Eliminar',
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildProspectsPage(String? currentUserId) {
    final DatabaseMethods _databaseMethods = DatabaseMethods();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestión de Prospectos'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              showSearch(
                context: context,
                delegate: ProspectSearchDelegate(
                  _databaseMethods,
                  currentUserId ?? "",
                ),
              );
            },
          ),
        ],
      ),
      /*floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const MultiStepForm()),
          );
        },
        backgroundColor: const Color.fromRGBO(51, 67, 139, 1),
        child: const Icon(Icons.add, color: Colors.white),
      ),*/
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Buscar prospectos',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onChanged: (value) {
                // Implement search functionality if needed
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _databaseMethods.getProspectsStream(
                currentUserId: currentUserId ?? "",
              ),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Center(
                    child: Text('No hay prospectos registrados'),
                  );
                }

                return ListView.builder(
                  itemCount: snapshot.data!.docs.length,
                  itemBuilder: (context, index) {
                    final doc = snapshot.data!.docs[index];
                    final prospect = doc.data() as Map<String, dynamic>;
                    final fechaRegistro =
                        (prospect['fechaRegistro'] as Timestamp?)?.toDate();

                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      child: ListTile(
                        title: Text(
                          '${prospect['nombre']} ${prospect['apellido']}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Tel: ${prospect['telefono'] ?? 'No especificado'}',
                            ),
                            if (fechaRegistro != null)
                              Text(
                                'Registrado: ${DateFormat('dd/MM/yyyy').format(fechaRegistro)}',
                                style: const TextStyle(fontSize: 12),
                              ),
                          ],
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.blue),
                              onPressed:
                                  () => _showEditDialog(doc.id, prospect),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => _confirmDelete(doc.id),
                            ),
                          ],
                        ),
                        onTap: () => _showDetailsDialog(prospect),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showDetailsDialog(Map<String, dynamic> prospect) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('${prospect['nombre']} ${prospect['apellido']}'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildDetailItem('Email', prospect['email']),
                _buildDetailItem('Teléfono', prospect['telefono']),
                _buildDetailItem('Dirección', prospect['direccion']),
                _buildDetailItem('Departamento', prospect['departamento']),
                _buildDetailItem('Municipio', prospect['municipio']),
                _buildDetailItem(
                  'Tipo de promoción',
                  prospect['tipoPromocion'],
                ),
                if (prospect['tipoPromocion'] == 'Nuevo') ...[
                  _buildDetailItem('Sabía de ADICLA', prospect['sabiaAdicla']),
                  _buildDetailItem('Cómo se enteró', prospect['comoSeEntero']),
                  _buildDetailItem('Etapa', prospect['etapa']),
                ],
                if (prospect['tipoPromocion'] == 'Referido')
                  _buildDetailItem('Referido por', prospect['referidoPor']),
              ],
            ),
          ),
          actions: [
            TextButton(
              child: const Text('Cerrar'),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDetailItem(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: RichText(
        text: TextSpan(
          style: DefaultTextStyle.of(context).style,
          children: [
            TextSpan(
              text: '$label: ',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: value ?? 'No especificado'),
          ],
        ),
      ),
    );
  }

  void _showEditDialog(String id, Map<String, dynamic> prospect) {
    final DatabaseMethods _databaseMethods = DatabaseMethods();
    final formKey = GlobalKey<FormState>();
    final nombreController = TextEditingController(text: prospect['nombre']);
    final apellidoController = TextEditingController(
      text: prospect['apellido'],
    );
    final telefonoController = TextEditingController(
      text: prospect['telefono'],
    );
    final emailController = TextEditingController(text: prospect['email']);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Editar Prospecto'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nombreController,
                    decoration: const InputDecoration(labelText: 'Nombre'),
                    validator:
                        (value) => value!.isEmpty ? 'Ingrese el nombre' : null,
                  ),
                  TextFormField(
                    controller: apellidoController,
                    decoration: const InputDecoration(labelText: 'Apellido'),
                    validator:
                        (value) =>
                            value!.isEmpty ? 'Ingrese el apellido' : null,
                  ),
                  TextFormField(
                    controller: telefonoController,
                    decoration: const InputDecoration(labelText: 'Teléfono'),
                    keyboardType: TextInputType.phone,
                  ),
                  TextFormField(
                    controller: emailController,
                    decoration: const InputDecoration(labelText: 'Email'),
                    keyboardType: TextInputType.emailAddress,
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.pop(context),
            ),
            ElevatedButton(
              child: const Text('Guardar'),
              onPressed: () async {
                if (formKey.currentState!.validate()) {
                  try {
                    await _databaseMethods.updateProspect(id, {
                      'nombre': nombreController.text,
                      'apellido': apellidoController.text,
                      'telefono': telefonoController.text,
                      'email': emailController.text,
                      'fechaActualizacion': FieldValue.serverTimestamp(),
                    });
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Prospecto actualizado')),
                      );
                      Navigator.pop(context);
                    }
                  } catch (e) {
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Error: ${e.toString()}')),
                      );
                    }
                  }
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _confirmDelete(String id) {
    final DatabaseMethods _databaseMethods = DatabaseMethods();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Confirmar eliminación'),
          content: const Text('¿Estás seguro de eliminar este prospecto?'),
          actions: [
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.pop(context),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white, // Color del texto
              ),
              child: const Text('Eliminar'),
              onPressed: () async {
                try {
                  await _databaseMethods.deleteProspect(id);
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Prospecto eliminado')),
                    );
                    Navigator.pop(context);
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Error: ${e.toString()}')),
                    );
                  }
                }
              },
            ),
          ],
        );
      },
    );
  }
}
