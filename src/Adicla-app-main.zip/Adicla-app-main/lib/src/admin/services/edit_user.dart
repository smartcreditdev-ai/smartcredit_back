import 'package:adicla/src/provider/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void editUserRotative(
  BuildContext context,
  String userId,
  String currentEmail,
  String currentRole,
  String agencia,
  bool isActive,
  bool approvedByAdmin,
) {
  final authService = Provider.of<AuthService>(context, listen: false);
  final emailController = TextEditingController(text: currentEmail);
  final agenciaController = TextEditingController();

  String selectedRole = currentRole;
  bool selectedIsActive = isActive;
  bool selectdIsAdmin = approvedByAdmin;

  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: Text('Editar Usuario: $currentEmail'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Correo Electrónico',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: agenciaController,
              decoration: const InputDecoration(
                labelText: 'Agencia',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.text,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: selectedRole,
              decoration: const InputDecoration(
                labelText: 'Rol',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'admin', child: Text('Administrador')),
                DropdownMenuItem(value: 'user', child: Text('Usuario')),
                DropdownMenuItem(
                  value: 'secretaria',
                  child: Text('Secretaria'),
                ),
                DropdownMenuItem(value: 'asesor', child: Text('Asesor')),
              ],
              onChanged: (value) {
                if (value != null) {
                  selectedRole = value;
                }
              },
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<bool>(
              value: selectdIsAdmin,
              decoration: const InputDecoration(
                labelText: 'Aprovado',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: true, child: Text('Activo')),
                DropdownMenuItem(value: false, child: Text('Inactivo')),
              ],
              onChanged: (value) {
                if (value != null) {
                  selectdIsAdmin = value;
                }
              },
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<bool>(
              value: selectedIsActive,
              decoration: const InputDecoration(
                labelText: 'Estado',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: true, child: Text('Activo')),
                DropdownMenuItem(value: false, child: Text('Inactivo')),
              ],
              onChanged: (value) {
                if (value != null) {
                  selectedIsActive = value;
                }
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () async {
              final email = emailController.text.trim();
              final role = selectedRole;
              final isActive = selectedIsActive;

              try {
                await authService.updateUserData(
                  uid: userId,
                  email: email,
                  role: role,
                  isActive: isActive,
                  agencia: '',
                  fechaInicio: '',
                  fechaFin: '',
                  isAproved: false,
                );

                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Usuario editado exitosamente'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error al actualizar: $e'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Editar Usuario'),
          ),
        ],
      );
    },
  );
}
