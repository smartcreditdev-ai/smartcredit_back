import 'package:flutter/material.dart';

void showAddUserDialog(BuildContext context) {
  final emailController = TextEditingController();
  final roleController = TextEditingController(text: 'user');

  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: const Text('Agregar Nuevo Usuario'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Correo Electrónico',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: roleController.text,
              decoration: const InputDecoration(
                labelText: 'Rol',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'admin', child: Text('Administrador')),
                DropdownMenuItem(value: 'user', child: Text('Usuario')),
                DropdownMenuItem(
                  value: 'secretaria',
                  child: Text('Secretaria'),
                ),
                DropdownMenuItem(value: 'asesor', child: Text('Asesor')),
              ],
              onChanged: (value) {
                if (value != null) {
                  roleController.text = value;
                }
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              // Aquí iría la lógica para crear el usuario en Firebase
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Usuario creado exitosamente'),
                  backgroundColor: Colors.green,
                ),
              );
            },
            child: const Text('Crear Usuario'),
          ),
        ],
      );
    },
  );
}
