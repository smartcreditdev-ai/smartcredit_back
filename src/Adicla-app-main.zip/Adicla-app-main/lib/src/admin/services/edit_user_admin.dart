import 'package:adicla/src/provider/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void editUser(
  BuildContext context,
  String userId,
  String currentEmail,
  String currentRole,
  bool isActive,
  bool approvedByAdmin,
) {
  final authService = Provider.of<AuthService>(context, listen: false);
  final emailController = TextEditingController(text: currentEmail);

  String selectedRole = currentRole;
  bool selectedIsActive = isActive;
  bool selectdIsAdmin = approvedByAdmin;
  List<String> agencias = [
    'Agencia Patzicía',
    'Agencia San Juan Comalapa',
    'Agencia San Martín Jilotepeq',
    'Agencia San Andrés Semetabaj',
    'Agencia Santa Lucía Cotz',
    'Agencia Santo Tomás La Unión',
    'Agencia Sololá',
    'Agencia Tecpán',
    'Agencia Mazatenango',
    'Agencia Guineales',
  ];

  String? agenciaSeleccionada;
  DateTime? fechaInicio;
  DateTime? fechaFin;

  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: Text('Editar Usuario: $currentEmail'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Correo Electrónico',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: selectedRole,
              decoration: const InputDecoration(
                labelText: 'Rol',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'admin', child: Text('Administrador')),
                DropdownMenuItem(value: 'user', child: Text('Usuario')),
                DropdownMenuItem(
                  value: 'secretaria',
                  child: Text('Secretaria'),
                ),
                DropdownMenuItem(value: 'asesor', child: Text('Asesor')),
              ],
              onChanged: (value) {
                if (value != null) {
                  selectedRole = value;
                }
              },
            ),
            const SizedBox(height: 16),
            if (selectedRole == 'secretaria' || selectedRole == 'asesor') ...[
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: agenciaSeleccionada,
                decoration: const InputDecoration(
                  labelText: 'Agencia asignada',
                  border: OutlineInputBorder(),
                ),
                items:
                    agencias
                        .map(
                          (agencia) => DropdownMenuItem(
                            value: agencia,
                            child: Text(agencia),
                          ),
                        )
                        .toList(),
                onChanged: (value) {
                  if (value != null) {
                    agenciaSeleccionada = value;
                  }
                },
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) fechaInicio = picked;
                },
                child: Text(
                  fechaInicio == null
                      ? 'Seleccionar Fecha Inicio'
                      : 'Inicio: ${fechaInicio!.toLocal()}'.split(' ')[0],
                ),
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) fechaFin = picked;
                },
                child: Text(
                  fechaFin == null
                      ? 'Seleccionar Fecha Fin'
                      : 'Fin: ${fechaFin!.toLocal()}'.split(' ')[0],
                ),
              ),
            ],
            const SizedBox(height: 5),
            DropdownButtonFormField<bool>(
              value: selectdIsAdmin,
              decoration: const InputDecoration(
                labelText: 'Aprovado',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: true, child: Text('Activo')),
                DropdownMenuItem(value: false, child: Text('Inactivo')),
              ],
              onChanged: (value) {
                if (value != null) {
                  selectdIsAdmin = value;
                }
              },
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<bool>(
              value: selectedIsActive,
              decoration: const InputDecoration(
                labelText: 'Estado',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: true, child: Text('Activo')),
                DropdownMenuItem(value: false, child: Text('Inactivo')),
              ],
              onChanged: (value) {
                if (value != null) {
                  selectedIsActive = value;
                }
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () async {
              final email = emailController.text.trim();
              final role = selectedRole;
              final isActive = selectedIsActive;
              final isAproved = selectdIsAdmin;

              try {
                await authService.updateUserData(
                  uid: userId,
                  email: email,
                  role: role,
                  isActive: isActive,
                  isAproved: isAproved,
                  agencia: agenciaSeleccionada,
                  fechaInicio: fechaInicio?.toIso8601String(),
                  fechaFin: fechaFin?.toIso8601String(),
                );

                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Usuario editado exitosamente'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error al actualizar: $e'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Editar Usuario'),
          ),
        ],
      );
    },
  );
}
