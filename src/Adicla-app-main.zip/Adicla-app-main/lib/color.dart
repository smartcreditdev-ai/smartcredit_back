import 'package:flutter/material.dart';

Color colorPrincipal = const Color.fromRGBO(51, 67, 139, 2);
